### Partial Assessment for Project Iteration 03 - Prelim-1_Features (Graded By: Shruti Verma)

#### Total score: _0_ / _8_

Run on May 14, 19:19:13 PM.


#### Prelim1 Release Branch

+ Pass: Checkout prelim 1 branch.




#### System Files and Lab Directory Structure

+ Pass: Copy directory "Files for Dependencies".



+ Pass: Check that directory "project" exists.

+ Pass: Check that directory "project/src" exists.

+ Pass: Copy directory "Files for Testing".



+ Pass: Change into directory "project".

+ Pass: Checkout regrade branch.



+ Pass: Change into directory "tests-i".

+ Fail: Check that make compiles.

    Make compile fails with errors:.
<pre>==== Auto-Generating Dependencies for ../src/observer.cc. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -MM -MF ../build/obj/tests-i/observer.d -MP -MT ../build/obj/tests-i/observer.o -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14 ../src/observer.cc
==== Compiling ../src/observer.cc into ../build/obj/tests-i/observer.o. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14  -c -o  ../build/obj/tests-i/observer.o ../src/observer.cc
==== Auto-Generating Dependencies for ../src/love_behavior.cc. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -MM -MF ../build/obj/tests-i/love_behavior.d -MP -MT ../build/obj/tests-i/love_behavior.o -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14 ../src/love_behavior.cc
==== Compiling ../src/love_behavior.cc into ../build/obj/tests-i/love_behavior.o. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14  -c -o  ../build/obj/tests-i/love_behavior.o ../src/love_behavior.cc
==== Auto-Generating Dependencies for ../src/light.cc. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -MM -MF ../build/obj/tests-i/light.d -MP -MT ../build/obj/tests-i/light.o -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14 ../src/light.cc
==== Compiling ../src/light.cc into ../build/obj/tests-i/light.o. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14  -c -o  ../build/obj/tests-i/light.o ../src/light.cc
==== Auto-Generating Dependencies for ../src/explore_behavior.cc. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -MM -MF ../build/obj/tests-i/explore_behavior.d -MP -MT ../build/obj/tests-i/explore_behavior.o -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14 ../src/explore_behavior.cc
==== Compiling ../src/explore_behavior.cc into ../build/obj/tests-i/explore_behavior.o. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14  -c -o  ../build/obj/tests-i/explore_behavior.o ../src/explore_behavior.cc
==== Auto-Generating Dependencies for ../src/motion_behavior.cc. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -MM -MF ../build/obj/tests-i/motion_behavior.d -MP -MT ../build/obj/tests-i/motion_behavior.o -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14 ../src/motion_behavior.cc
==== Compiling ../src/motion_behavior.cc into ../build/obj/tests-i/motion_behavior.o. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14  -c -o  ../build/obj/tests-i/motion_behavior.o ../src/motion_behavior.cc
==== Auto-Generating Dependencies for ../src/graphics_arena_viewer.cc. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -MM -MF ../build/obj/tests-i/graphics_arena_viewer.d -MP -MT ../build/obj/tests-i/graphics_arena_viewer.o -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14 ../src/graphics_arena_viewer.cc
==== Compiling ../src/graphics_arena_viewer.cc into ../build/obj/tests-i/graphics_arena_viewer.o. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14  -c -o  ../build/obj/tests-i/graphics_arena_viewer.o ../src/graphics_arena_viewer.cc
==== Auto-Generating Dependencies for ../src/motion_behavior_differential.cc. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -MM -MF ../build/obj/tests-i/motion_behavior_differential.d -MP -MT ../build/obj/tests-i/motion_behavior_differential.o -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14 ../src/motion_behavior_differential.cc
==== Compiling ../src/motion_behavior_differential.cc into ../build/obj/tests-i/motion_behavior_differential.o. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14  -c -o  ../build/obj/tests-i/motion_behavior_differential.o ../src/motion_behavior_differential.cc
==== Auto-Generating Dependencies for ../src/predator.cc. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -MM -MF ../build/obj/tests-i/predator.d -MP -MT ../build/obj/tests-i/predator.o -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14 ../src/predator.cc
==== Compiling ../src/predator.cc into ../build/obj/tests-i/predator.o. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -g -Wall -Wextra -pthread -fprofile-arcs -ftest-coverage -c -I/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -std=c++14  -c -o  ../build/obj/tests-i/predator.o ../src/predator.cc
../src/predator.cc: In member function void csci3081::Predator::Disguise():
../src/predator.cc:165:23: error: too few arguments to function int rand_r(unsigned int*)
     randNum = (rand_r() % 3) + 1;
                       ^
In file included from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/cstdlib:75:0,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/ext/string_conversions.h:41,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/bits/basic_string.h:6159,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/string:52,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/bits/locale_classes.h:40,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/bits/ios_base.h:41,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/ios:42,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/ostream:38,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/iostream:39,
                 from ../src/predator.cc:9:
/usr/include/stdlib.h:459:12: note: declared here
 extern int rand_r (unsigned int *__seed) __THROW;
            ^~~~~~
../src/predator.cc:190:23: error: too few arguments to function int rand_r(unsigned int*)
     randNum = (rand_r() % 2) + 1;
                       ^
In file included from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/cstdlib:75:0,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/ext/string_conversions.h:41,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/bits/basic_string.h:6159,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/string:52,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/bits/locale_classes.h:40,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/bits/ios_base.h:41,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/ios:42,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/ostream:38,
                 from /soft/gcc/7.1.0/Linux_x86_64/include/c++/7.1.0/iostream:39,
                 from ../src/predator.cc:9:
/usr/include/stdlib.h:459:12: note: declared here
 extern int rand_r (unsigned int *__seed) __THROW;
            ^~~~~~
Makefile:139: recipe for target '../build/obj/tests-i/predator.o' failed
make: *** [../build/obj/tests-i/predator.o] Error 1
</pre>



+ Skip: Change into directory "..".

  This test was not run because of an earlier failing test.

+ Skip: Check that file "./build/bin/tests-i" exists.

  This test was not run because of an earlier failing test.


#### Functionality- Decoration Alone

+  _0_ / _1_ : Skip: Decorates Once - Gets through first decoration without a seg fault (scenes/pred_decorate_1.json)

  This test was not run because of an earlier failing test.

+  _0_ / _1_ : Skip: Decorates Twice - Gets through second decoration without a seg fault (scenes/pred_decorate_2.json)

  This test was not run because of an earlier failing test.

+  _0_ / _1_ : Skip: Decorates Thrice - Gets through third decoration without a seg fault (scenes/pred_decorate_3.json)

  This test was not run because of an earlier failing test.

+  _0_ / _1_ : Skip: Starves - Dies after 3rd decoration (scenes/pred_starve.json)

  This test was not run because of an earlier failing test.


#### Functionality - Consuming BV

+  _0_ / _1_ : Skip: Movement Towards BV - Does it move towards BV as a Predator or Decorated as BV? (scenes/pred_move_towards_bv.json)

  This test was not run because of an earlier failing test.

+  _0_ / _1_ : Skip: Undecorates - Does it undecorate after consuming BV? (scenes/pred_undecorates.json)

  This test was not run because of an earlier failing test.


#### Functionality - Decorator Behavior

+  _0_ / _2_ : Skip: Moves as a BV when decorated as BV. (scenes/pred_bv_decorator.json)

  This test was not run because of an earlier failing test.


#### Regrade Process

You may create json config files that prove that your functionality works in the "regrade/iteration3-prelim1" branch under the "project/scenes" folder.  Use the names for the scene files above.  Submit a new regrade request and we will re-run with your new files and a description of how to test.


#### Possible Areas of Failure

 * Cannot turn off mobility of entity (i.e. cannot call entity->set_is_moving(...)).
 * Program expects a BV to exist.
 * The BV must be the first entity in the config.
 * Simulation timing is handled outside of the arena_->AdvanceTime(1.0).
 * Segfault when a predator consumes.

#### Total score: _0_ / _8_

