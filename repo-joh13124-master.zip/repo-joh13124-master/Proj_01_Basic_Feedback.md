### Feedback for Proj 01

Run on March 14, 20:32:30 PM.


***Note: This is just the basic feedback.  The full feedback is run daily as a batch process (click link below)***


Link to full feedback: [Proj_01_Full_Feedback.md](Proj_01_Full_Feedback.md)

+ Pass: Checkout devel branch.



+ Pass: Report branch name.




#### System Files and Lab Directory Structure

+ Pass: Copy directory "Files for Dependencies".



+ Pass: Check that directory "project" exists.

+ Pass: Check that directory "project/src" exists.

+ Pass: Copy directory "Files for Testing".



+ Pass: Change into directory "project".


#### Git Usage

+ Pass: Check git commit history
Commits found=60

+ Pass: Run git ls-remote gather all branches in repo

87469a294a0e43a79dee70e3abc1683ec9cc07e3	refs/heads/Factory_unit_tests

288ab001d12ff5a837c4fb1d6706a7e600d8f7f0	refs/heads/Tests

029b323fe4ef701df43190d557d3baeea9b7783b	refs/heads/devel

85025651575170221b6970108c0a36a7d00cdc95	refs/heads/exercise5

043c01af6e510a368db0a2a97f9ed30ec0404bbd	refs/heads/feature_enhancements

9d421f379090f6bde654a09c5f8212e5fe8d0336	refs/heads/fix/01-compilation-errors

21fa49d161366253316353d1258a1fa3b685a8c1	refs/heads/fix/02-robot-overlap2

051d37909d534b8188b2a6950fe20c8fcf8def65	refs/heads/fix/05-final-documentation

f9cea31af83e49973931b1a4283512706f172f28	refs/heads/master




#### Git Issue Usage

+ Pass: Configuring GHI

+ Pass: Run ghi for total number of open issues in Github repo (Found: 2)

[OPEN issue #12] :  Dynamic Color changing

[OPEN issue #11] :  Improved Design





+ Pass: Run ghi for total number of closed issues in Github repo (Found: 9)

[CLOSED issue #10] :  Google style 1

[CLOSED issue #9] :  Color Change 1

[CLOSED issue #8] :  Robot Collision 1

[CLOSED issue #7] :  Tests ↑

[CLOSED issue #6] :  Changed names and locations of pdfs for feedback ↑

[CLOSED issue #5] :  Feature enhancements ↑

[CLOSED issue #4] :  fix(factory classes): Fixed small mistakes in classes ↑

[CLOSED issue #3] :  Tests: Added factory classes for each of the arena entities ↑

[CLOSED issue #1] :  Fixed compliation errors for project. ↑






#### Documentation Tests

+ Pass: Check that file "docs/uml_design.pdf" exists.


Link to full feedback: [Proj_01_Full_Feedback.md](Proj_01_Full_Feedback.md)


#### Style Tests

+ Pass: Ensuring code follows style guide.




#### Compile Tests


Link to full feedback: [Proj_01_Full_Feedback.md](Proj_01_Full_Feedback.md)


#### Unit Tests


Link to full feedback: [Proj_01_Full_Feedback.md](Proj_01_Full_Feedback.md)

