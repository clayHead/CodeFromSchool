### Partial Assessment for Project Iteration 03 - Final-Automated (Graded By: Nikki Kyllonen)

#### Total score: _10.0_ / _18_

Run on May 15, 17:56:29 PM.


#### Release Branch

+ Pass: Checkout release branch.




#### System Files and Lab Directory Structure

+ Pass: Copy directory "Files for Dependencies".



+ Pass: Check that directory "project" exists.

+ Pass: Check that directory "project/src" exists.

+ Pass: Copy directory "Files for Testing".



+ Pass: Change into directory "project".


#### Google Style

+  _0_ / _5_ : Fail: Make sure final submission code is style compliant.

<pre>cd src; make check-style
make[1]: Entering directory '/export/scratch/nikki/3081-s19/csci3081-grading-env/grading-scripts/grading/Proj_03_Final-Automated_Assessment/repo-joh13124/project/src'
==== Checking style is correct ====
/export/scratch/nikki/3081-s19/csci3081-grading-env/grading-scripts/grading/Proj_03_Final-Automated_Assessment/repo-joh13124/cpplint/cpplint.py --root=.. *.cc *.h
Ignoring "mainpage.h": file excluded by "/export/scratch/nikki/3081-s19/csci3081-grading-env/grading-scripts/grading/Proj_03_Final-Automated_Assessment/repo-joh13124/project/src/CPPLINT.cfg". File path component "mainpage.h" matches pattern "mainpage.h"
parse_csv.h:40:  Static/global string variables are not permitted.  [runtime/string] [4]
Done processing aggressive_behavior.cc
Done processing arena.cc
Done processing base_behavior.cc
Done processing braitenberg_vehicle.cc
Done processing controller.cc
Done processing coward_behavior.cc
Done processing explore_behavior.cc
Done processing factory.cc
Done processing food.cc
Done processing graphics_arena_viewer.cc
Done processing light.cc
Done processing love_behavior.cc
Done processing main.cc
Done processing motion_behavior.cc
Done processing motion_behavior_differential.cc
Done processing observer.cc
Done processing predator.cc
Done processing rgb_color.cc
Done processing aggressive_behavior.h
Done processing arena_entity.h
Done processing arena.h
Done processing arena_immobile_entity.h
Done processing arena_mobile_entity.h
Done processing arena_viewer.h
Done processing base_behavior.h
Done processing behavior_enum.h
Done processing braitenberg_vehicle.h
Done processing common.h
Done processing controller.h
Done processing coward_behavior.h
Done processing entity_type.h
Done processing explore_behavior.h
Done processing factory.h
Done processing food.h
Done processing graphics_arena_viewer.h
Done processing light.h
Done processing love_behavior.h
Done processing motion_behavior_differential.h
Done processing motion_behavior.h
Done processing observer.h
Done processing params.h
Done processing parse_csv.h
Done processing pose.h
Done processing predator.h
Done processing rgb_color.h
Done processing wheel_velocity.h
Total errors found: 1
Makefile:162: recipe for target 'check-style' failed
make[1]: *** [check-style] Error 1
make[1]: Leaving directory '/export/scratch/nikki/3081-s19/csci3081-grading-env/grading-scripts/grading/Proj_03_Final-Automated_Assessment/repo-joh13124/project/src'
Makefile:8: recipe for target 'check-style' failed
make: *** [check-style] Error 2
</pre>




#### Git Tests

+  _0_ / _3_ : Fail: Check git commit history
Insufficient commits (found=18,required=25)

+  _5_ / _5_ : Pass: Counting branches made for Iteration 3

Sufficient branches found (found=2, required=2):

csv_config

predator_extension


#### Git Issue Usage

+ Pass: Configuring GHI

+  _5.0_ / _5_ : Pass: Run ghi for total number of issues in Github repo (Found: 4, Expected: 2) 

 [OPEN issue #22] :  Directories

[CLOSED issue #21] :  Bv's dont interact with predators

[CLOSED issue #20] :  Bv's colliding with iight

[CLOSED issue #19] :  Predators dont move 1

 



#### Total score: _10.0_ / _18_

