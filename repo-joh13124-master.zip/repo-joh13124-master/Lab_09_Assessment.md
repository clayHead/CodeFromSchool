### Assessment for Lab 09

#### Total score: _20_ / _100_

Run on March 04, 14:10:59 PM.


#### System Files and Lab Directory Structure

+  _10_ / _10_ : Pass: Copy directory "Files for Dependencies".



+  _5_ / _5_ : Pass: Check that directory "labs" exists.

+  _5_ / _5_ : Pass: Check that directory "labs/lab09_robots" exists.

+ Pass: Change into directory "labs/lab09_robots".

+  _0_ / _5_ : Fail: Check that make compiles.

    Make compile fails with errors:.
<pre>make -C src all
make[1]: Entering directory '/classes/grades/Spring-2019/csci3081/shaw0162/csci3081-grading-env/grading-scripts/grading/Lab_09_Assessment_Larson/repo-joh13124/labs/lab09_robots/src'
==== Auto-Generating Dependencies for robot_viewer.cc. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -MM -MF ../build/obj/src/robot_viewer.d -MP -MT ../build/obj/src/robot_viewer.o -W -Wall -g -std=c++14 -Wno-unused -c -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0 robot_viewer.cc
==== Compiling robot_viewer.cc into ../build/obj/src/robot_viewer.o. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -W -Wall -g -std=c++14 -Wno-unused -c -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -c -o  ../build/obj/src/robot_viewer.o robot_viewer.cc
==== Auto-Generating Dependencies for robot_land.cc. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -MM -MF ../build/obj/src/robot_land.d -MP -MT ../build/obj/src/robot_land.o -W -Wall -g -std=c++14 -Wno-unused -c -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0 robot_land.cc
==== Compiling robot_land.cc into ../build/obj/src/robot_land.o. ====
/soft/gcc/7.1.0/Linux_x86_64/bin/g++ -W -Wall -g -std=c++14 -Wno-unused -c -I.. -I. -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/nanovg -isystem/classes/grades/Spring-2019/csci3081/csel-s19c3081/include/MinGfx-1.0  -c -o  ../build/obj/src/robot_land.o robot_land.cc
robot_land.cc:16:1: error: redefinition of RobotLand::RobotLand()
 RobotLand::RobotLand() {
 ^~~~~~~~~
In file included from robot_land.cc:10:0:
../src/robot_land.h:35:3: note: RobotLand::RobotLand() previously defined here
   RobotLand(void) {
   ^~~~~~~~~
robot_land.cc:21:1: error: redefinition of RobotLand::~RobotLand()
 RobotLand::~RobotLand() {
 ^~~~~~~~~
In file included from robot_land.cc:10:0:
../src/robot_land.h:40:3: note: RobotLand::~RobotLand() previously defined here
   ~RobotLand(void) {
   ^
robot_land.cc:27:67: error: no bool RobotLand::get_robot_pos(int, double*, double*) member function declared in class RobotLand
 bool RobotLand::get_robot_pos(int id, double *x_pos, double *y_pos) {
                                                                   ^
robot_land.cc:44:67: error: no bool RobotLand::get_robot_vel(int, double*, double*) member function declared in class RobotLand
 bool RobotLand::get_robot_vel(int id, double *x_vel, double *y_vel) {
                                                                   ^
Makefile:105: recipe for target '../build/obj/src/robot_land.o' failed
make[1]: *** [../build/obj/src/robot_land.o] Error 1
make[1]: Leaving directory '/classes/grades/Spring-2019/csci3081/shaw0162/csci3081-grading-env/grading-scripts/grading/Lab_09_Assessment_Larson/repo-joh13124/labs/lab09_robots/src'
Makefile:14: recipe for target 'proj01' failed
make: *** [proj01] Error 2
</pre>



+ Skip: Copy directory "Files for Testing".

  This test was not run because of an earlier failing test.

+ Skip: Change into directory "Lab09".

  This test was not run because of an earlier failing test.

+  _0_ / _10_ : Skip: Check that make compiles.

  This test was not run because of an earlier failing test.

+  _0_ / _5_ : Skip: Check that directory "../build/bin" exists.

  This test was not run because of an earlier failing test.

+  _0_ / _15_ : Skip: Check that a GoogleTest test passes.

  This test was not run because of an earlier failing test.

+  _0_ / _15_ : Skip: Check that a GoogleTest test passes.

  This test was not run because of an earlier failing test.

+  _0_ / _15_ : Skip: Check that a GoogleTest test passes.

  This test was not run because of an earlier failing test.

+  _0_ / _15_ : Skip: Check that a GoogleTest test passes.

  This test was not run because of an earlier failing test.

#### Total score: _20_ / _100_

