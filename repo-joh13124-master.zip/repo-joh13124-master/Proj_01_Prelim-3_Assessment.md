### Partial Assessment for Project Iteration 01 - Prelim-3 (Graded By: Dan Orban)

#### Total score: _8.0_ / _8_

Run on April 16, 04:50:48 AM.


#### Pre-Release Branch

+ Pass: Checkout pre-release branch.




#### System Files and Lab Directory Structure

+ Pass: Copy directory "Files for Dependencies".



+ Pass: Check that directory "project" exists.

+ Pass: Check that directory "project/src" exists.

+ Pass: Copy directory "Files for Testing".



+ Pass: Change into directory "project".


#### Functionality

+  _2_ / _2_ : Pass: Check that make compiles.



+ Pass: Check that file "src/braitenberg_vehicle.cc" exists.

+ Pass: Peparing repository



+  _1.0_ / _1_ : Pass: Aggressive functionality



+  _1.0_ / _1_ : Pass: Coward functionality



+  _1.0_ / _1_ : Pass: Love functionality



+  _1.0_ / _1_ : Pass: Explore functionality



+  _1.0_ / _1_ : Pass: Color functionality



+  _1.0_ / _1_ : Pass: Collision functionality



#### Total score: _8.0_ / _8_

