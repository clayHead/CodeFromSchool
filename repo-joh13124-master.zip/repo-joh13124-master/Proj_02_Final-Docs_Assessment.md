### Partial Assessment for Project Iteration 02 - Final-Docs (Graded By: Shruti Verma)

#### Total score: _0_ / _0_

Run on May 08, 15:04:44 PM.


#### Release Branch

+ Pass: Checkout release branch.




#### System Files and Lab Directory Structure

+ Pass: Copy directory "Files for Dependencies".



+ Pass: Check that directory "project" exists.

+ Pass: Check that directory "project/src" exists.

+ Pass: Copy directory "Files for Testing".



+ Pass: Change into directory "project".


#### Design

+ Fail: Check that file "docs/iteration2_design.pdf" exists.

     "docs/iteration2_design.pdf" not found.


<pre>Graded on Canvas - check Canvas rubric for results.</pre>


#### Doxygen


<pre>Graded on Canvas - check Canvas rubric for results.</pre>

+ Pass: Documentation builds.



+ Pass: Check that file "docs/html/index.html" exists.

+ Pass: Check that file "src/mainpage.h" exists.

+ Pass: Graded on Canvas.



#### Total score: _0_ / _0_

