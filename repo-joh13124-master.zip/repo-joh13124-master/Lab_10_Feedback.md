### Feedback for Lab 10

Run on March 04, 13:39:44 PM.


#### Git Usage

+ Pass: Run git ls-remote to check for existence of specific branch- Branch devel found

+ Pass: Checkout devel branch.



+ Pass: Run git ls-remote gather all branches in repo

df343d13bedaddc0a076aaec689ed7d489064d9c	refs/heads/devel

85025651575170221b6970108c0a36a7d00cdc95	refs/heads/exercise5

9d421f379090f6bde654a09c5f8212e5fe8d0336	refs/heads/fix/01-compilation-errors

21fa49d161366253316353d1258a1fa3b685a8c1	refs/heads/fix/02-robot-overlap2

e736138c93e50c610ee063cbbc58d4aa2c31b0e0	refs/heads/master



+ Pass: Run git ls-remote to check for # of branches in repo
Sufficient branches (found=5,required=3)


#### Necessary Files and Structure

+ Pass: Copy directory "Files for Dependencies".



+ Pass: Check that directory "labs" exists.

+ Pass: Check that directory "labs/lab10_advanced_git" exists.


#### Essential Files Exist

+ Pass: Check that directory "project" exists.

+ Pass: Copy directory "Files for Testing".



+ Pass: Change into directory "project".

+ Pass: Check that file "Makefile" exists.


### Test that code compiles and creates the exectuable

+ Pass: Check that make compiles.



