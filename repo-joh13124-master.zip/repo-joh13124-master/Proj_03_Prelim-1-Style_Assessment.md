### Partial Assessment for Project Iteration 03 - Prelim-1-Style (Graded By: Nikki Kyllonen)

#### Total score: _5_ / _5_

Run on May 15, 16:50:31 PM.


#### Prelim1 Release Branch

+ Pass: Checkout prelim 1 branch.




#### System Files and Lab Directory Structure

+ Pass: Copy directory "Files for Dependencies".



+ Pass: Check that directory "project" exists.

+ Pass: Check that directory "project/src" exists.

+ Pass: Copy directory "Files for Testing".



+ Pass: Change into directory "project".


#### Style Tests

+  _5_ / _5_ : Pass: Grading style compliancy errors (Found: 0 errors)

#### Total score: _5_ / _5_

