### Feedback for Lab 08

Run on February 25, 14:43:36 PM.


#### System Files and Directory Structure

+ Pass: Check that directory "labs" exists.

+ Pass: Check that directory "labs/lab08_gdb" exists.

+ Pass: Change into directory "labs/lab08_gdb".


#### Test that code compiles and creates the exectuable

+ Pass: Check that make compiles.



+ Pass: Check that file "date" exists.

+ Pass: Program executes flawlessly.



+ Pass: Check for correct output.

    Complete.



