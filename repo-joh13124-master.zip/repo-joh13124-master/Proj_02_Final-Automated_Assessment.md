### Partial Assessment for Project Iteration 02 - Final-Automated (Graded By: Nikki Kyllonen)

#### Total score: _13.571428571428571_ / _18_

Run on May 06, 20:26:40 PM.


#### Release Branch

+ Pass: Checkout release branch.




#### System Files and Lab Directory Structure

+ Pass: Copy directory "Files for Dependencies".



+ Pass: Check that directory "project" exists.

+ Pass: Check that directory "project/src" exists.

+ Pass: Copy directory "Files for Testing".



+ Pass: Change into directory "project".


#### Google Style

+  _5_ / _5_ : Pass: Make sure code is style compliant.




#### Git Tests

+  _0_ / _3_ : Fail: Check git commit history
Insufficient commits (found=0,required=25)

+  _3.5714285714285716_ / _5_ : Pass: Counting branches made for Iteration 2

Insufficient branches found (found=5, required=7):

ObserverPattern

Working_srategy_pattern

it2pri1

predator

strategy_patern


#### Git Issue Usage

+ Pass: Configuring GHI

+  _5.0_ / _5_ : Pass: Run ghi for total number of issues in Github repo (Found: 8, Expected: 7) 

 [OPEN issue #] : 

[CLOSED issue #] : 

[CLOSED issue #18] :  Bv wont change color after starving

[CLOSED issue #17] :  Bv will move after dying

[CLOSED issue #16] :  BV will stop when colliding with food 1

[CLOSED issue #15] :  Fix memory leak when changing behavior

[CLOSED issue #14] :  Fix(): Stratgey Pattern ↑

[CLOSED issue #13] :  Strategy patern ↑

[CLOSED issue #11] :  Improved Design

 



#### Total score: _13.571428571428571_ / _18_

