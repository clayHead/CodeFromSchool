#ifndef SRC_OBSTACLE_H_
#define SRC_OBSTACLE_H_

/**
 * @file robot_land.h
 *
 * @copyright 2017 Clayton Johsnon, All rights reserved.
 */

 /*******************************************************************************
  * Includes
  ******************************************************************************/
#include <utility>

 /*******************************************************************************
  * Class Definitions
  ******************************************************************************/
 /**
  * @brief The class for obstacles blocking the way for robots in the simulation
  *
  * Obstacles have a radius and a position.
  */

class Obstacle {
 public:
        Obstacle() : radius_(10) , position_(20.0, 20.0) {}
        /**
        * @brief Return radius of obstacle
        *
        * @return radius as an int
        */
        int get_radius() {return radius_;}
        /**
        * @brief position of the obstacles
        *
        * @return pair of doubles which is the position of the obstacle
        */
        std::pair<double, double> get_pos() {return pos_;}
 private:
        int radius_;
        std::pair<double, double> pos_;
}

#endif /* SRC_OBSTACLE_H_ */
