#ifndef SRC_MAINPAGE_H_
#define SRC_MAINPAGE_H_

```
/*! \mainpage Lab07_stylve_doxy
 *
 * \section intro_sec Introduction
 *
 * Lab07. Which taught Google style and deoxygen
 * Copyright[2019]
 *
 */
```
#endif /* SRC_MAINPAGE_H_ */
