# This is a heading for documentation of my lab.
Lab01 Github Basics creates two files.
The private file will not be tracked via git, but this will.

If you want to learn more about Markdown, which is an 
html-like language for creating the readme.md file that 
every repo should have and probably most directories too,
see https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet
