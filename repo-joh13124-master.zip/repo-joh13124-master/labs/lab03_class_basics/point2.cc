#include "iostream"
#include "math.h"
#include "stdio.h"

#include "point2.h"

Point2::Point2(float x, float y) {
    x_ = x;
    y_ = y;
}

float Point2::DistanceBetween(Point2 point) {
  float x = (point.x_-x_);
  float y = (point.y_-y_);
  return sqrt((x*x)+(y*y));
}

int Point2::Quadrant() {
    if (x_ == 0 && y_ == 0) {
        return 0;
    }
    else if (x_ > 0 && y_ > 0) { // y is 0 or bigger (on y axis or above)
        return 1;
    }
    else if (x_ > 0 && y_ == 0) {
        return 1;
    }
    else if (x_ < 0 && y_ > 0) {
        return 2;
    }
    else if (x_ == 0 && y_ > 0) {
      return 2;
    }
    else if (x_ < 0 && y_ < 0) {
        return 3;
    }
    else if (x_ < 0 && y_ == 0) {
      return 3;
    }
    else return 4;
}

void Point2::Print() {
    printf("[%f,%f]", x_, y_);
}
