#ifndef LAB03_CLASS_BASICS_H_
#define LAB03_CLASS_BASICS_H_

class Point2
{
public:
    Point2(float x=0, float y=0);
    float DistanceBetween(Point2 point);
    int Quadrant();
    void Print();
private:
    float x_;
    float y_;
};

#endif /* LAB03_CLASS_BASICS_H_ */