//
//  quack_quack.cpp
//
//  Created by Seth Johnson on 2/4/15.
//  Copyright (c) 2015 Seth Johnson. All rights reserved.
//

#include <iostream>
#include "quack_quack.h"

using std::cout;
using std::endl;

void QuackQuack::Quack() {
    cout << "QUACK!!" << endl;
}
