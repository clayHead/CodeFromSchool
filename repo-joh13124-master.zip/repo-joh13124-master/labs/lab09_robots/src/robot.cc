/**
 * @file robot_land.cc
 *
 * @copyright 201 3081 Staff, All rights reserved.
 */

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "src/robot.h"

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

void Robot::Update(double dt) {
  double old_x = position_.x_;
  double old_y = position_.y_;

  position_.x_ = 512 + 200.0 * cos(dt);
  position_.y_ = 350 + 200.0 * sin(dt);

  double x_vel = position_.x_ - old_x;
  double y_vel = position_.y_ - old_y;

  direction_ = std::atan2(y_vel, x_vel);
}
