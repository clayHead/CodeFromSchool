/**
 * @file robot_land.h
 *
 * @copyright 2017 3081 Staff, All rights reserved.
 */

#ifndef SRC_ROBOT_H_
#define SRC_ROBOT_H_

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <cmath>
#include <iostream>
#include "point.h"

/**
 * @brief An entity in RobotLand that moves around the window.
 *
 * Its id, size, initial position, and velocity are fixed.
 * The position and direction are updated at each frame refresh.
 * The color can be changed via a user button in the RobotViewer.
 */
class Robot {

public:
  /**
   * @brief A Robot is instantiated with a user-defined id, radius, and origin.
   * The constructor must also set the position, direction, color,
   * and sensor range and angle.
   *
   * @param[in] id The identifying number of the robot (now just 0 or 1)
   * @param[in] radius The radius of the graphics circle representing the robot.
   * @param[in] origin The {x,y} position around which the robot rotates.
   * @param[in] speed It controls the speed at which robot moves in circle
   */
	Robot(int id, double radius, Point origin, double speed) {
    id_ = id;
    radius_ = radius;
    color_ = false;
    origin_ = origin;
    speed_ = speed;
    Update(0);
    // position_ = new Point(512, 400)
    // direction_ = 0.0;
    sensor_angle_ = 2.0;
    sensor_range_ = 3.0 * radius_;
  }

  /**
    * @brief Given time, update the {x,y} position and direction angle of the Robot.
    *
    * @param[in] time The sim_time since the start of the simulator.
    */
  void Update(double time);

  bool get_color() {return color_;}
  void set_color(bool color) {color_ = color;}
  int get_id() {return id_;}
  double get_radius() {return radius_;}
  Point get_position() {return position_;}
  double get_direction() {return direction_;}
  double get_sensor_angle() {return sensor_angle_;}
  double get_sensor_range() {return sensor_range_;}

private:
  int id_;
  double radius_;  // pixel units for size of robot in graphics window.
  bool color_;     // "true" will color in the robot, "false" leaves it white.
  Point origin_;   // center of circle around which robot is rotating
  double speed_;    // fixed constant to control rate of movement
  Point position_; // current {x,y} position in graphics window
  double direction_; // current directional angle in radians
  double sensor_angle_; // angle between sensors relative to robot center.
  double sensor_range_;  // distance range of sensor.
};

#endif  // SRC_ROBOT_H_
