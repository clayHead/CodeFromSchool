### Partial Assessment for Project Iteration 01 - GitPartial (Graded By: Lakshya)

#### Total score: _17.0_ / _17_

Run on April 01, 12:40:58 PM.


#### Git Tests

+  _3_ / _3_ : Pass: Check git commit history
Sufficient commits (found=63,required=25)

+  _5.0_ / _5_ : Pass: Run git ls-remote to check for # of branches in repo (Found: 12, Expected: 11)


#### Git Issue Usage

+ Pass: Configuring GHI

+  _5.0_ / _5_ : Pass: Run ghi for total number of issues in Github repo (Found: 12, Expected: 11) 

 [OPEN issue #12] :  Dynamic Color changing

[OPEN issue #11] :  Improved Design

[CLOSED issue #13] :  Strategy patern ↑

[CLOSED issue #10] :  Google style 1

[CLOSED issue #9] :  Color Change 1

[CLOSED issue #8] :  Robot Collision 1

[CLOSED issue #7] :  Tests ↑

[CLOSED issue #6] :  Changed names and locations of pdfs for feedback ↑

[CLOSED issue #5] :  Feature enhancements ↑

[CLOSED issue #4] :  fix(factory classes): Fixed small mistakes in classes ↑

[CLOSED issue #3] :  Tests: Added factory classes for each of the arena entities ↑

[CLOSED issue #1] :  Fixed compliation errors for project. ↑

 



+  _2_ / _2_ : Pass: Run ghi for total number of closed issues in Github repo (Found: 10)

[CLOSED issue #13] :  Strategy patern ↑

[CLOSED issue #10] :  Google style 1

[CLOSED issue #9] :  Color Change 1

[CLOSED issue #8] :  Robot Collision 1

[CLOSED issue #7] :  Tests ↑

[CLOSED issue #6] :  Changed names and locations of pdfs for feedback ↑

[CLOSED issue #5] :  Feature enhancements ↑

[CLOSED issue #4] :  fix(factory classes): Fixed small mistakes in classes ↑

[CLOSED issue #3] :  Tests: Added factory classes for each of the arena entities ↑

[CLOSED issue #1] :  Fixed compliation errors for project. ↑





+  _2_ / _2_ : Pass: Run ghi for total number of open issues in Github repo (Found: 2)

[OPEN issue #12] :  Dynamic Color changing

[OPEN issue #11] :  Improved Design






#### Complete Git Assessment


The complete breakdown of grades will be on canvas.

#### Total score: _17.0_ / _17_

