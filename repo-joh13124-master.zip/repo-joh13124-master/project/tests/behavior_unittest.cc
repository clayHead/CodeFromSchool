/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <gtest/gtest.h>
#include <string>
#include "src/entity_type.h"
#include "src/params.h"
#include "src/aggressive_behavior.h"
#include "src/base_behavior.h"
#include "src/love_behavior.h"
#include "src/explore_behavior.h"
#include "src/coward_behavior.h"
#include "src/wheel_velocity.h"

 /******************************************************
* TEST FEATURE SetUp
*******************************************************/

class BehaviorTest : public ::testing::Test {
protected:
  virtual void SetUp() {
    base = new csci3081::BaseBehavior();
    aggressive = new csci3081::AggressiveBehavior();
    coward = new csci3081::CowardBehavior();
    love = new csci3081::LoveBehavior();
    explore = new csci3081::ExploreBehavior();
  }

  virtual void TearDown() {
    delete base;
    delete aggressive;
    delete coward;
    delete love;
    delete explore;
  }

  csci3081::BaseBehavior* base;
  csci3081::AggressiveBehavior* aggressive;
  csci3081::CowardBehavior* coward;
  csci3081::LoveBehavior* love;
  csci3081::ExploreBehavior* explore;

  double reading_close = 1800.0/std::pow(1.08, 10); // 833.74827855...
  double reading_far = 1800.0/std::pow(1.08, 99); // 0.883772266...
};

TEST_F(BehaviorTest, AggressiveTest) {
  csci3081::WheelVelocity expected_close_close = csci3081::WheelVelocity(5,5);
  csci3081::WheelVelocity expected_close_far = csci3081::WheelVelocity(5,1800.0/std::pow(1.08, 99));
  csci3081::WheelVelocity expected_far_close = csci3081::WheelVelocity(1800.0/std::pow(1.08, 99),5);

  EXPECT_EQ(aggressive->UpdateWheel(reading_close,reading_close,5).left,
    expected_close_close.left) << "Close Close left not set properly";
    EXPECT_EQ(aggressive->UpdateWheel(reading_close,reading_close,5).right,
      expected_close_close.right) << "Close Close right not set properly";

  EXPECT_EQ(aggressive->UpdateWheel(reading_close,reading_far,5).left,
    expected_close_far.left) << "Close Far left not set properly";
    EXPECT_EQ(aggressive->UpdateWheel(reading_close,reading_far,5).right,
      expected_close_far.right) << "Close Far right not set properly";

  EXPECT_EQ(aggressive->UpdateWheel(reading_far,reading_close,5).left,
    expected_close_close.left) << "Far Close left not set properly";
    EXPECT_EQ(aggressive->UpdateWheel(reading_far,reading_close,5).right,
      expected_far_close.right) << "Far Close right not set properly";
};

TEST_F(BehaviorTest, CowardTest) {
  csci3081::WheelVelocity expected_close_close = csci3081::WheelVelocity(5,5);
  csci3081::WheelVelocity expected_close_far = csci3081::WheelVelocity(5,1800.0/std::pow(1.08, 99));
  csci3081::WheelVelocity expected_far_close = csci3081::WheelVelocity(1800.0/std::pow(1.08, 99),5);

  EXPECT_EQ(coward->UpdateWheel(reading_close,reading_close,5).left,
    expected_close_close.left) << "Close Close left not set properly";
    EXPECT_EQ(coward->UpdateWheel(reading_close,reading_close,5).right,
      expected_close_close.right) << "Close Close right not set properly";

  EXPECT_EQ(coward->UpdateWheel(reading_close,reading_far,5).left,
    expected_close_far.left) << "Close Far left not set properly";
    EXPECT_EQ(coward->UpdateWheel(reading_close,reading_far,5).right,
      expected_close_far.right) << "Close Far right not set properly";

  EXPECT_EQ(coward->UpdateWheel(reading_far,reading_close,5).left,
    expected_close_close.left) << "Far Close left not set properly";
    EXPECT_EQ(coward->UpdateWheel(reading_far,reading_close,5).right,
      expected_far_close.right) << "Far Close right not set properly";
};

TEST_F(BehaviorTest, ExploreTest) {
  csci3081::WheelVelocity expected_close_close = csci3081::WheelVelocity(1/5,1/5);
  csci3081::WheelVelocity expected_close_far = csci3081::WheelVelocity(1/5,1/(1800.0/std::pow(1.08, 99)));
  csci3081::WheelVelocity expected_far_close = csci3081::WheelVelocity(1/(1800.0/std::pow(1.08, 99)),1/5);

  EXPECT_EQ(explore->UpdateWheel(reading_close,reading_close,5).left,
    expected_close_close.left) << "Close Close left not set properly";
    EXPECT_EQ(explore->UpdateWheel(reading_close,reading_close,5).right,
      expected_close_close.right) << "Close Close right not set properly";

  EXPECT_EQ(explore->UpdateWheel(reading_close,reading_far,5).left,
    expected_close_far.left) << "Close Far left not set properly";
    EXPECT_EQ(explore->UpdateWheel(reading_close,reading_far,5).right,
      expected_close_far.right) << "Close Far right not set properly";

  EXPECT_EQ(explore->UpdateWheel(reading_far,reading_close,5).left,
    expected_close_close.left) << "Far Close left not set properly";
    EXPECT_EQ(explore->UpdateWheel(reading_far,reading_close,5).right,
      expected_far_close.right) << "Far Close right not set properly";
};

TEST_F(BehaviorTest, LoveTest) {
  csci3081::WheelVelocity expected_close_close = csci3081::WheelVelocity(1/5,1/5);
  csci3081::WheelVelocity expected_close_far = csci3081::WheelVelocity(1/5,1/(1800.0/std::pow(1.08, 99)));
  csci3081::WheelVelocity expected_far_close = csci3081::WheelVelocity(1/(1800.0/std::pow(1.08, 99)),1/5);

  EXPECT_EQ(love->UpdateWheel(reading_close,reading_close,5).left,
    expected_close_close.left) << "Close Close left not set properly";
    EXPECT_EQ(love->UpdateWheel(reading_close,reading_close,5).right,
      expected_close_close.right) << "Close Close right not set properly";

  EXPECT_EQ(love->UpdateWheel(reading_close,reading_far,5).left,
    expected_close_far.left) << "Close Far left not set properly";
    EXPECT_EQ(love->UpdateWheel(reading_close,reading_far,5).right,
      expected_close_far.right) << "Close Far right not set properly";

  EXPECT_EQ(love->UpdateWheel(reading_far,reading_close,5).left,
    expected_close_close.left) << "Far Close left not set properly";
    EXPECT_EQ(love->UpdateWheel(reading_far,reading_close,5).right,
      expected_far_close.right) << "Far Close right not set properly";
};
