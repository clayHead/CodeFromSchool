/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <gtest/gtest.h>
#include <string>
#include "src/entity_type.h"
#include "src/params.h"
#include "src/factory.h"
#include "src/braitenberg_vehicle.h"
#include "src/light.h"
#include "src/food.h"

 /******************************************************
* TEST FEATURE SetUp
*******************************************************/
class FactoryTest : public ::testing::Test {

 protected:
  virtual void SetUp() {
    food_json = "{\"type\": \"Food\", \"x\":200, \"y\":200, \"r\":20, \"theta\": 0.0 }";
    bv_json = "{\"type\": \"Braitenberg\", \"x\":270, \"y\":270, \"r\":15, \"theta\": 215, \"light_behavior\": \"None\", \"food_behavior\": \"Explore\" }";
    light_json = "{\"type\": \"Light\", \"x\":150, \"y\":300, \"r\":25 }";

    configF_ = new json_value();
    std::string errF = parse_json(configF_,food_json);
    configB_ = new json_value();
    std::string errB = parse_json(configB_,bv_json);
    configL_ = new json_value();
    std::string errL = parse_json(configL_,light_json);
  }
  virtual void TearDown() {
    // delete &food_json;
    // delete &bv_json;
    // delete &light_json;
    delete configF_;
    delete configB_;
    delete configL_;
  }

  std::string food_json;
  std::string bv_json;
  std::string light_json;
  json_value* configF_;
  json_value* configB_;
  json_value* configL_;
};

/*******************************************************************************
 * Test Cases
 ******************************************************************************/

TEST_F(FactoryTest, FoodMake) {
  // make json string. Parse it, then check it

  csci3081::ArenaEntity* food =
    csci3081::Factory::create(&configF_->get<json_object>());

  EXPECT_EQ(food->get_name(),"Food");
};

TEST_F(FactoryTest, BVMake) {
  // make json string. Parse it, then check it

  csci3081::ArenaEntity* bv =
    csci3081::Factory::create(&configB_->get<json_object>());

  EXPECT_EQ(bv->get_name(),"Braitenberg 1");
};

TEST_F(FactoryTest, LightMake) {
  // make json string. Parse it, then check it

  csci3081::ArenaEntity* light =
    csci3081::Factory::create(&configL_->get<json_object>());

  EXPECT_EQ(light->get_name(),"Light 1");
};
