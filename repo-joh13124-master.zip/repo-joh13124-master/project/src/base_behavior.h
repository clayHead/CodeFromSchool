/**
 * @file base_behavior.h
 *
 * @copyright 2019 Clayton Johnson, All rights reserved.
 */

#ifndef SRC_BASE_BEHAVIOR_H_
#define SRC_BASE_BEHAVIOR_H_

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "src/common.h"
#include "src/wheel_velocity.h"
#include "src/arena_mobile_entity.h"
#include "src/behavior_enum.h"

/*******************************************************************************
 * Namespaces
 ******************************************************************************/
NAMESPACE_BEGIN(csci3081);

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief Class managing an ArenaMobileEntity's position.
 */

class BaseBehavior {
 public:
    BaseBehavior() = default;
    virtual ~BaseBehavior() = default;

    BaseBehavior(const BaseBehavior& other) = default;
    BaseBehavior& operator=(const BaseBehavior& other) = default;

    /**
     * @brief Update wheel velocity of entity
     *
     * @param[in] sensor_reading Reading from entity sensor
     * @param[in] default_speed Default speed of robot
     *
     * @param[out] Updated wheel velocity
     */
    virtual WheelVelocity UpdateWheel(double sensor_right_reading,
      double sensor_left_reading, double default_speed);

    /**
     * @brief Return a behavior based a string. Used in initialization
     *
     */
    virtual Behavior GetBehaviorType() {
        return kNone;
    }
};

NAMESPACE_END(csci3081);

#endif  // SRC_BASE_BEHAVIOR_H_
