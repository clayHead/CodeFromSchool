/**
 * @file braitenberg_vehicle.h
 *
 * @copyright 2017 3081 Staff, All rights reserved.
 */

#ifndef SRC_BRAITENBERG_VEHICLE_H_
#define SRC_BRAITENBERG_VEHICLE_H_

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include <ctime>
#include <string>
#include <vector>
#include "src/common.h"
#include "src/arena_mobile_entity.h"
#include "src/motion_behavior_differential.h"
#include "src/observer.h"
#include "src/wheel_velocity.h"
#include "src/behavior_enum.h"
#include "src/base_behavior.h"
#include "src/aggressive_behavior.h"
#include "src/love_behavior.h"
#include "src/coward_behavior.h"
#include "src/explore_behavior.h"

/*******************************************************************************
 * Namespaces
 ******************************************************************************/
NAMESPACE_BEGIN(csci3081);

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
class Observer;
/**
 * @brief Entity class to represent a Braitenberg Vehicle
 *
 * A braitenberg vehicle is a simple machine that is used to show how simple
 * concepts (in this case wiring) can give way to complex looking behavior. In
 * this simulation, Braitenberg vehicles contain sensors, which can be hooked
 * up in four different ways, and thus they can exhibit four different behaviors
 */

class BraitenbergVehicle : public ArenaMobileEntity {
 public:
  /**
   * @brief Default constructor.
   */
  BraitenbergVehicle();

  /**
   * @brief Copy constructor
   *
   * Deleting the copy constructor. required now with
   *  inclusion of references to sensors and motion_handler/behavior
   */
  BraitenbergVehicle(const BraitenbergVehicle & rhs) = delete;

  /**
   * @brief Copy assignment
   *
   * Deleting the copy assignment. required now with inclusion
   *  of references to sensores and motion_handler/behavior
   */
  BraitenbergVehicle operator=(const BraitenbergVehicle & rhs) = delete;

  /**
   * @brief Update the BraitenbergVehicle's position and velocity after the
   * specified duration has passed.
   *
   * @param dt The # of timesteps that have elapsed since the last update.
   */
  void TimestepUpdate(unsigned int dt) override;

  /**
   * @brief The process of updating the vechile by one timstep
   */
  void Update() override;

  /**
   * @brief Change the movement state of the BraitenbergVehicle.
   */
  void HandleCollision(EntityType ent_type,
                       ArenaEntity * object = NULL) override;

  /**
   * @brief Sense an Entity
   *
   * @param entity The entity in which the vechile is sensing
   */
  void SenseEntity(const ArenaEntity& entity);

  std::string get_name() const override;

  /**
   * @brief Return the light sensors of the vehicle as a const
   *
   * @return Position of light sensors as a const
   */
  std::vector<Pose> get_light_sensors_const() const;

  /**
   * @brief Return light sensors of the vehicle
   *
   * @return Position of light sensors
   */
  std::vector<Pose> get_light_sensors();

  /**
   * @brief Updates the light sensors
   */
  void UpdateLightSensors();

  /**
   * @brief Intializes robot based off json value
   *
   * @param[in] entity_config a json file with parameters
   */
  void LoadFromObject(json_object * entity_config_pointer) override;

  /**
   * @brief Get behavior of vehicle towards light
   *
   * @return Behavior towards light
   */
  Behavior get_light_behavior() {return light_behavior_->GetBehaviorType();}

  /**
   * @brief Set behavior towards light
   *
   * @param[in] behavior New behavior towards light
   */
  void set_light_behavior(Behavior behavior) {
    if (light_behavior_ != nullptr) delete light_behavior_;
    switch (behavior) {
      case kAggressive:
        light_behavior_ = new AggressiveBehavior();
        break;
      case kCoward:
        light_behavior_ = new CowardBehavior();
        break;
      case kLove:
        light_behavior_ = new LoveBehavior();
        break;
      case kExplore:
        light_behavior_ = new ExploreBehavior();
        break;
      case kNone:
      default:
        light_behavior_ = new BaseBehavior();
        break;
    }
  }

  /**
   * @brief Get behavior of vehicle towards food
   *
   * @return Behavior towards food
   */
  Behavior get_food_behavior() {return food_behavior_->GetBehaviorType();}

  /**
   * @brief Set behavior towards food
   *
   * @param[in] behavior New behavior towards food
   */
  void set_food_behavior(Behavior behavior) {
    if (food_behavior_ != nullptr) delete food_behavior_;
    switch (behavior) {
      case kAggressive:
        food_behavior_ = new AggressiveBehavior();
        break;
      case kCoward:
        food_behavior_ = new CowardBehavior();
        break;
      case kLove:
        food_behavior_ = new LoveBehavior();
        break;
      case kExplore:
        food_behavior_ = new ExploreBehavior();
        break;
      case kNone:
      default:
        food_behavior_ = new BaseBehavior();
        break;
    }
  }

  /**
   * @brief Get behavior of vehicle towards bv's
   *
   * @return Behavior towards bv's
   */
  Behavior get_bv_behavior() { return bv_behavior_->GetBehaviorType(); }

  /**
   * @brief Set behavior towards bv's
   *
   * @param[in] behavior New behavior towards bv's
   */
  void set_bv_behavior(Behavior behavior) {
    if (bv_behavior_ != nullptr) delete bv_behavior_;
    switch (behavior) {
      case kAggressive:
        bv_behavior_ = new AggressiveBehavior();
        break;
      case kCoward:
        bv_behavior_ = new CowardBehavior();
        break;
      case kLove:
        bv_behavior_ = new LoveBehavior();
        break;
      case kExplore:
        bv_behavior_ = new ExploreBehavior();
        break;
      case kNone:
      default:
        bv_behavior_ = new BaseBehavior();
        break;
    }
  }

  /**
   * @brief Return reading of left sensor
   *
   * @param[in] entity Entity sensor is reading
   *
   * @return Double of the reading
   */
  double get_sensor_reading_left(const ArenaEntity* entity);

  /**
   * @brief Return reading of right sensor
   *
   * @param[in] entity Entity sensor is reading
   *
   * @return Double of the reading
   */
  double get_sensor_reading_right(const ArenaEntity* entity);

  /**
   * @brief Int count of the total number of vehicles
   */
  static int count;

  void Notify();

  void Subscribe(Observer* observer);

  void Unsubscribe(Observer* observer);

  void Die();

  void ConsumeFood() {food_counter_ = 0;}

 protected:
  std::vector<Pose> light_sensors_;
  MotionBehaviorDifferential * motion_behavior_{nullptr};
  WheelVelocity wheel_velocity_;
  std::vector<WheelVelocity> wheel_velocities_;
  BaseBehavior* light_behavior_;
  BaseBehavior* food_behavior_;
  BaseBehavior* bv_behavior_;
  const ArenaEntity* closest_light_entity_;
  const ArenaEntity* closest_food_entity_;
  const ArenaEntity* closest_bv_entity_;
  double defaultSpeed_;
  int collision_counter_;
  bool collision_mode_;  // true if in collision handle mode, false for normal
  std::vector<Observer*> observer_collection_;
  int food_counter_;
};

NAMESPACE_END(csci3081);

#endif  // SRC_BRAITENBERG_VEHICLE_H_
