/**
 * @file light.h
 *
 * @copyright 2017 3081 Staff, All rights reserved.
 */

#ifndef SRC_MAINPAGE_H_
#define SRC_MAINPAGE_H_

```
/*! \mainpage CSSI 3081w Project
 *
 * \section intro_sec Introduction
 *
 * Robot simulation involving food, light, robots, and predators. In order to run the simulation
 * navigate the terminal to project/scenes and run "../build/bin/arenaviwer X_DIM Y_DIM CONGIF.json" or
 * "../build/bin/arenaviwer X_DIM Y_DIM CONGIF.csv". The X_DIM, and Y_DIM are the dimensions of the window.
 * These can be doubles. The recomended size is 600 by 600.
 *
 * This simulation uses a Model-viewer-controller pattern to simulate robots reacting to stimuli.
 * An overview can be found here (https://en.wikipedia.org/wiki/Model–view–controller). The basics
 * are: the model, which manages data, logic, and rules; the view, which is a representation of
 * information; and the controller, which accepts input and converts it to commands for the model.
 * In this code, our model is the arena, the viwer is the GraphicsArenaViewer, and the controller
 * is named as such.
 *
 * It is important to understand what exatcly a  BraitenbergVehicle is
 * (https://en.wikipedia.org/wiki/Braitenberg_vehicle). Braitenberg vehicles are a basic model to
 * simulate animal-like interactions using robots. Robots have behaviors based on their positive or
 * negative connection, as well as a crossed or direct connection between sensors and motors. The
 * University of Sussex has a good overview, found here.
 * (http://users.sussex.ac.uk/~christ/crs/kr-ist/lecx1a.html)
 *
 * Along with MVC, there were various other design patterns used. The factory pattern
 * (https://en.wikipedia.org/wiki/Factory_method_pattern), is used to create entities upon start of
 * the simulation. Note the use of static methods in the factory class. If another entity type were
 * to be added, it would need a switch case in the factory class. Other consideration needed are
 * in the arena during UpdateEntityTimestep() if the entity has iteractions with other entities, and
 * in GraphicsArenaViewer to draw the certain entities and any interface they may need.
 *
 * The strategy pattern (https://en.wikipedia.org/wiki/Strategy_pattern) was used to break up
 * handling of variables and reduce code bloat. All updates to a Bratienberg's wheel velocity is
 * handled here. If another behavior were to be added, a behavior enum would need to be added,
 * as well as a new class derived from basebehavior.
 *
 * The Observer pattern (https://en.wikipedia.org/wiki/Observer_pattern), was used to view real time
 * updates as to how the various stimuli influced the robots behavior. GraphicsArenaViewer inherits
 * from a base observer class, while BraienbergVehicle has the subject methods inside it. If another
 * object wanted to be observed, it would also need to include the subject methods. If this were to
 * be something that needed to be added, it is recomended that the subject methods be moved to a
 * subject base class, which BraitenbergVehicle and another subject could inherit from. The reason
 * the subject methods are currently were they are is because per the design requirements for this
 * project, only BraitenbergVehicles needed to be observed.
 *
 * The decorator pattern was considered in order to implement predator disguise functionality
 * (https://en.wikipedia.org/wiki/Decorator_pattern). This would have allowed the predators
 * to be wrapped in decorator classes that would extend their functionality and allow for disguising
 * as other entities. However, for this assignment, disguise functionality was hardcoded into the
 * predator. This makes the code simple, but not extensible. If one were to want ot extend this
 * disguise behavior to other classes, an abstract decorator class as well as concrete decorators
 * for each entity would need to be added, as well as additional code to guide this disguising in the
 * main Arena loop.
 *
 */
```

#endif /* SRC_MAINPAGE_H_ */
