/**
 * @file aggressive_behavior.h
 *
 * @copyright 2019 Clayton Johnson, All rights reserved.
 */

#ifndef SRC_AGGRESSIVE_BEHAVIOR_H_
#define SRC_AGGRESSIVE_BEHAVIOR_H_

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "src/common.h"
#include "src/base_behavior.h"
#include "src/wheel_velocity.h"
#include "src/arena_mobile_entity.h"

/*******************************************************************************
 * Namespaces
 ******************************************************************************/
NAMESPACE_BEGIN(csci3081);

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
/**
 * @brief Class managing an ArenaMobileEntity's position.
 *
 * Makes entity steer away from other entities and move faster while
 *  farther away
 */

class AggressiveBehavior : public BaseBehavior {
 public:
    AggressiveBehavior() = default;
    ~AggressiveBehavior() = default;

    AggressiveBehavior(const AggressiveBehavior& other) = default;
    AggressiveBehavior& operator=(const AggressiveBehavior& other) = default;

    /**
     * @brief Update the wheel velocity of entity
     *
     * @param[in] sensor_reading Reading from entity sensor
     * @param[in] default_speed Default speed of robot
     *
     * @param[out] Updated wheel velocity
     */
    WheelVelocity UpdateWheel(double sensor_right_reading,
      double sensor_left_reading,
      double default_speed) override;

    Behavior GetBehaviorType() override {
        return kAggressive;
    }
};

NAMESPACE_END(csci3081);

#endif  // SRC_AGGRESSIVE_BEHAVIOR_H_
