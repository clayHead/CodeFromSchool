/**
 * @file coward_behavior.cc
 *
 * @copyright 2019 Clayton Johnson, all rights reserved.
 */

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <iostream>

#include "src/coward_behavior.h"
#include "src/wheel_velocity.h"

/*******************************************************************************
 * Namespaces
 ******************************************************************************/
NAMESPACE_BEGIN(csci3081);

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

WheelVelocity CowardBehavior::UpdateWheel(double sensor_right_reading,
  double sensor_left_reading, double default_speed) {
    return WheelVelocity(sensor_left_reading, sensor_right_reading,
      default_speed);
}

NAMESPACE_END(csci3081);
