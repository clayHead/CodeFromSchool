/**
 * @file love_behavior.cc
 *
 * @copyright 2019 Clayton Johnson, all rights reserved.
 */

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <iostream>

#include "src/love_behavior.h"
#include "src/wheel_velocity.h"

/*******************************************************************************
 * Namespaces
 ******************************************************************************/
NAMESPACE_BEGIN(csci3081);

/*******************************************************************************
 * Member Functions
 ******************************************************************************/

WheelVelocity LoveBehavior::UpdateWheel(double sensor_right_reading,
  double sensor_left_reading, double default_speed) {
    return WheelVelocity(1.0/sensor_left_reading, 1.0/sensor_right_reading,
      default_speed);
}

NAMESPACE_END(csci3081);
