/**
 * @file predator.h
 *
 * @copyright Clayton Johnson 2019. All rights reserved.
 */

#ifndef SRC_PREDATOR_H_
#define SRC_PREDATOR_H_

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include <ctime>
#include <string>
#include <vector>
#include "src/common.h"
#include "src/braitenberg_vehicle.h"
#include "src/motion_behavior_differential.h"
#include "src/wheel_velocity.h"
#include "src/behavior_enum.h"
#include "src/base_behavior.h"
#include "src/aggressive_behavior.h"
#include "src/love_behavior.h"
#include "src/coward_behavior.h"
#include "src/explore_behavior.h"

/*******************************************************************************
* Namespaces
*******************************************************************************/
NAMESPACE_BEGIN(csci3081);

/*******************************************************************************
* Class Definitions
*******************************************************************************/
 /**
  * @brief Class for predators which eat BV's and are sacred of light
  */
class Predator : public BraitenbergVehicle {
 public:
  /**
   * @brief Predator's Constructor
   */
  Predator();

  Predator(const Predator& p) = default;

  /**
   * @brief The process of updating the predator by one timstep
   */
  void Update() override;

  /**
   * @brief Change the movement state of the predator.
   */
  void HandleCollision(EntityType ent_type,
                       ArenaEntity * object = NULL) override;

  std::string get_name() const override;

  /**
   * @brief Return the light sensors of the predator as a const
   *
   * @return Position of light sensors as a const
   */
  std::vector<Pose> get_light_sensors_const() const;

  /**
   * @brief Intializes predator based off json value
   *
   * @param[in] entity_config a json file with parameters
   */
  void LoadFromObject(json_object * entity_config_pointer) override;

  /**
   * @brief desguise predator
   *
   */
  void Disguise();

  bool is_disguised() {return is_disguised_;}

  std::vector<EntityType> get_assumed() {return assumed_;}

  EntityType get_disguised_type() { return disguised_type_; }

  EntityType get_type() const {
    if (is_disguised_) {
      return disguised_type_;
    }
    return get_type();
  }

  /**
   * @brief Int count of the total number of vehicles
   */
  static int count;

  void Notify() = delete;

  void Subscribe(Observer* observer) = delete;

  void Unsubscribe(Observer* observer) = delete;

 private:
    std::vector<EntityType> assumed_;
    bool is_disguised_;
    EntityType disguised_type_;
};

NAMESPACE_END(csci3081);

#endif  // SRC_PREDATOR_H_
