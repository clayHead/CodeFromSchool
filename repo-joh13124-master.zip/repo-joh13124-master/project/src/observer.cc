/**
 * @file observer.cc
 *
 * @copyright Claton Johnson, 2019. All rights reserved.
 */

 /*******************************************************************************
  * Includes
  ******************************************************************************/

#include "src/observer.h"

/*******************************************************************************
 * Namespaces
 ******************************************************************************/
NAMESPACE_BEGIN(csci3081);

Observer::Observer() : velocities_(), sub_() {
  velocities_ = std::vector<WheelVelocity>(3);
  sub_ = nullptr;
}

void Observer::Update(std::vector<WheelVelocity> velocities) {
  velocities_ = velocities;
}

NAMESPACE_END(csci3081);
