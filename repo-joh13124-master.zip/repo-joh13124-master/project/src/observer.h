/**
 * @file observer.h
 *
 * @copyright Clayton Johnson, 2019. All rights reserved
 */

#ifndef SRC_OBSERVER_H_
#define SRC_OBSERVER_H_

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include <vector>
#include "src/wheel_velocity.h"
#include "src/braitenberg_vehicle.h"

 /******************************************************************************
  * Namespaces
  *****************************************************************************/
NAMESPACE_BEGIN(csci3081);

/******************************************************************************
* Class Definitions
*****************************************************************************/

class BraitenbergVehicle;
  /**
   * @brief Observer of Braitenberg vechiles to send data
   *
   */

class Observer {
 public:
  /**
   * @brief Default constructor for observer Class
   */
  Observer();

  virtual ~Observer() = default;

  Observer(const Observer& other) = delete;

  Observer operator=(const Observer& other) = delete;

  /**
   * @brief Updates state of observer
   *
   * @param velocities New vector of velocities to represent the new state
   */
  virtual void Update(std::vector<WheelVelocity> velocities);

  std::vector<WheelVelocity> getVelocities() {return velocities_;}

  void UpdateSub(BraitenbergVehicle* sub) {sub_ = sub;}

  BraitenbergVehicle* getSub() {return sub_;}

 private:
  std::vector<WheelVelocity> velocities_;
  BraitenbergVehicle* sub_;
};

NAMESPACE_END(csci3081);

#endif  // SRC_OBSERVER_H_
