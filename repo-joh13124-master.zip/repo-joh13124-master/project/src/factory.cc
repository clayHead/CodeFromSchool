/**
 * @file factory.cc
 *
 * @copyright Clayton Johnson, All rights reserved.
 */

#include <string>
#include "src/factory.h"
#include "src/params.h"

NAMESPACE_BEGIN(csci3081);

ArenaEntity * Factory::create(json_object * entity_config_pointer) {
  json_object& entity_config = *entity_config_pointer;
  EntityType etype = get_entity_type(entity_config["type"].get<std::string>());

  ArenaEntity * entity = NULL;

  switch (etype) {
    case (kLight):
      entity = new Light();
      break;
    case (kFood):
      entity = new Food();
      break;
    case (kBraitenberg):
      entity = new BraitenbergVehicle();
      break;
    case (kPredator):
      entity = new Predator();
      break;
    default:
      std::cout << "FATAL: Bad entity type on creation" << std::endl;
      assert(false);
  }

  entity->LoadFromObject(entity_config_pointer);

  return entity;
}

NAMESPACE_END(csci3081);
