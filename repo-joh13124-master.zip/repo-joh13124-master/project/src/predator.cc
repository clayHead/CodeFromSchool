/**
 * @file predator.cc
 *
 * @copyright Clayton Johnson. All rights reserved.
 */
/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <iostream>
#include <ctime>
#include "src/predator.h"
#include "src/params.h"

/*******************************************************************************
 * Namespaces
 ******************************************************************************/
NAMESPACE_BEGIN(csci3081);

int Predator::count = 0;

/*******************************************************************************
 * Constructors/Destructor
 ******************************************************************************/

Predator::Predator() : assumed_(), is_disguised_(false),
disguised_type_(kPredator) {
  set_type(kPredator);
  assumed_ = std::vector<EntityType>(0);

  srand(time(NULL));

  // Set ID
  count++;
  set_id(count);
}

void Predator::HandleCollision(EntityType ent_type,
                               ArenaEntity * object) {
  if (ent_type == kBraitenberg) {
    if (food_counter_ < 600) {
      static_cast<BraitenbergVehicle*>(object)->Die();
      food_counter_ = 0;
      assumed_.clear();
      set_type(kPredator);
      is_disguised_ = false;
    }
  } else if (ent_type == kLight ||
             ent_type == kFood || ent_type == kUndefined) {
    return;
  } else {
    // Wall. Normal collision handling
    set_heading(static_cast<int>((get_pose().theta + 180)) % 360);
    collision_mode_ = true;
  }
}

void Predator::Update() {
  if (food_counter_ == 150) {
    Disguise();
  } else if (food_counter_ == 300) {
    Disguise();
  } else if (food_counter_ == 450) {
    Disguise();
  } else if (food_counter_ >= 600) {
    Die();
    return;
  }
  food_counter_++;

  if (get_disguised_type() == kFood || get_disguised_type() == kLight) {
    return;
  }

  if (!collision_mode_) {
    int numBehaviors = 3;

    WheelVelocity light_wheel_velocity = WheelVelocity(0, 0);

    if (light_behavior_ != nullptr &&
        light_behavior_->GetBehaviorType() != kNone) {
      light_wheel_velocity =
        light_behavior_->UpdateWheel(
          get_sensor_reading_right(closest_light_entity_),
          get_sensor_reading_left(closest_light_entity_),
          defaultSpeed_);
    } else {
      numBehaviors--;
    }

    wheel_velocities_[0] = light_wheel_velocity;

    WheelVelocity food_wheel_velocity = WheelVelocity(0, 0);

    if (food_behavior_->GetBehaviorType() != kNone) {
      food_wheel_velocity =
        food_behavior_->UpdateWheel(
          get_sensor_reading_right(closest_food_entity_),
          get_sensor_reading_left(closest_food_entity_),
          defaultSpeed_);
    } else {
      numBehaviors--;
    }

    wheel_velocities_[1] = food_wheel_velocity;

    WheelVelocity bv_wheel_velocity = WheelVelocity(0, 0);

    if (bv_behavior_ != nullptr && bv_behavior_->GetBehaviorType() != kNone) {
      bv_wheel_velocity =
        bv_behavior_->UpdateWheel(
          get_sensor_reading_right(closest_bv_entity_),
          get_sensor_reading_left(closest_bv_entity_),
          defaultSpeed_);
    } else {
      numBehaviors--;
    }

    wheel_velocities_[2] = bv_wheel_velocity;

    if (numBehaviors) {
      wheel_velocity_ = WheelVelocity(
        (light_wheel_velocity.left + bv_wheel_velocity.left)/numBehaviors,
        (light_wheel_velocity.right + bv_wheel_velocity.right)/numBehaviors,
        defaultSpeed_);
    } else {
      wheel_velocity_ = WheelVelocity(0, 0);
    }
  } else {
    if (collision_counter_ < 20) {
      wheel_velocity_ = WheelVelocity(5, 5, defaultSpeed_);
      collision_counter_++;
    } else {
      collision_mode_ = false;
      collision_counter_ = 0;
      set_heading(static_cast<int>((get_pose().theta + 180)) % 360);
      set_heading(static_cast<int>((get_pose().theta + 45)) % 360);
    }
  }
}

std::string Predator::get_name() const {
  return "Predator " + std::to_string(get_id());
}

void Predator::LoadFromObject(json_object * entity_config_pointer) {
  json_object& entity_config = *entity_config_pointer;
  ArenaEntity::LoadFromObject(&entity_config);

  set_light_behavior(kCoward);

  set_food_behavior(kNone);

  set_bv_behavior(kAggressive);

  UpdateLightSensors();
}

void Predator::Disguise() {
  printf("Getting a disguise. I am now a ");
  is_disguised_ = true;

  int randNum;
  if (assumed_.size() == 0) {  // Three options
    printf("(three options) ");
    thread_local unsigned int seedp = time(NULL);
    randNum = (rand_r(&seedp) % 3) + 1;

    switch (randNum) {
      case (1):  // food
        disguised_type_ = kFood;
        assumed_.push_back(kFood);
        printf("food\n");
        wheel_velocity_ = WheelVelocity(0, 0);
        break;
      case (2):  // light
        disguised_type_ = kLight;
        assumed_.push_back(kLight);
        printf("light\n");
        wheel_velocity_ = WheelVelocity(0, 0);
        break;
      case (3):  // Braitenberg
        disguised_type_ = kBraitenberg;
        assumed_.push_back(kBraitenberg);
        printf("braitenberg\n");
        break;
      default:
        printf("Shit something has gone wrong\n");
    }
  } else if (assumed_.size() == 1) {  // Two options
    printf("(two options) ");
    thread_local unsigned int seedp = time(NULL);
    randNum = (rand_r(&seedp) % 2) + 1;

    if (assumed_[0] == kFood) {  // Light or braitenberg
      switch (randNum) {
        case (1):  // light
          disguised_type_ = kLight;
          assumed_.push_back(kLight);
          printf("light\n");
          wheel_velocity_ = WheelVelocity(0, 0);
          break;
        case (2):
          disguised_type_ = kBraitenberg;
          assumed_.push_back(kBraitenberg);
          printf("braitenberg\n");
          break;
        default:
          printf("Shit something has gone wrong\n");
      }
    } else if (assumed_[0] == kLight) {  // Food or braitenberg
      switch (randNum) {
        case (1):  // food
          disguised_type_ = kFood;
          assumed_.push_back(kFood);
          printf("food\n");
          wheel_velocity_ = WheelVelocity(0, 0);
          break;
        case (2):
          disguised_type_ = kBraitenberg;
          assumed_.push_back(kBraitenberg);
          printf("braitenberg\n");
          break;
        default:
          printf("Shit something has gone wrong\n");
      }
    } else {  // light or food
      switch (randNum) {
        case (1):  // light
          disguised_type_ = kLight;
          assumed_.push_back(kLight);
          printf("light\n");
          wheel_velocity_ = WheelVelocity(0, 0);
          break;
        case (2):
          disguised_type_ = kFood;
          assumed_.push_back(kFood);
          printf("food\n");
          wheel_velocity_ = WheelVelocity(0, 0);
          break;
        default:
          printf("Shit something has gone wrong\n");
      }
    }
  } else if (assumed_.size() == 2) {  // One option
    printf("(one options) ");
    if ((assumed_[0] == kLight && assumed_[1] == kBraitenberg) ||
        (assumed_[0] == kBraitenberg && assumed_[1] == kLight)) {  // food
          disguised_type_ = kFood;
          assumed_.push_back(kFood);
          printf("food\n");
          wheel_velocity_ = WheelVelocity(0, 0);
    } else if ((assumed_[0] == kFood && assumed_[1] == kBraitenberg) ||
              (assumed_[0] == kBraitenberg && assumed_[1] == kFood)) {  // Light
          disguised_type_ = kLight;
          assumed_.push_back(kLight);
          printf("light\n");
          wheel_velocity_ = WheelVelocity(0, 0);
    } else {  // braitenberg
      disguised_type_ = kBraitenberg;
      assumed_.push_back(kBraitenberg);
      printf("braitenberg\n");
    }
  }  // end of one option
}  // end of disguise

NAMESPACE_END(csci3081);
