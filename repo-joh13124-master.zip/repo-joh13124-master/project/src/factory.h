/**
 * @file factory.h
 *
 * @copyright Clayton Johnson, All rights reserved.
 */

#ifndef SRC_FACTORY_H_
#define SRC_FACTORY_H_


/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "src/common.h"
#include "src/arena_entity.h"
#include "src/food.h"
#include "src/light.h"
#include "src/braitenberg_vehicle.h"
#include "src/predator.h"

/*******************************************************************************
 * Namespaces
 ******************************************************************************/
NAMESPACE_BEGIN(csci3081);

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/

/**
 * @brief The main class for factories which create other entities
 *
 *
 *
 */

class Factory {
 public:
    /**
     * @brief Create an entity according to the passed json
     */
    static ArenaEntity * create(json_object * enity_object_pointer);
};

NAMESPACE_END(csci3081);

#endif  // SRC_FACTORY_H_
