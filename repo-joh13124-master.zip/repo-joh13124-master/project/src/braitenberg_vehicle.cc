/**
 * @file braitenberg_vehicle.cc
 *
 * @copyright 2017 3081 Staff, All rights reserved.
 */
/*******************************************************************************
 * Includes
 ******************************************************************************/
#include <iostream>
#include <ctime>
#include "src/braitenberg_vehicle.h"
#include "src/params.h"
#include "src/rgb_color.h"
#include "src/predator.h"

class SensorLightLove;

/*******************************************************************************
 * Namespaces
 ******************************************************************************/
NAMESPACE_BEGIN(csci3081);

int BraitenbergVehicle::count = 0;

/*******************************************************************************
 * Constructors/Destructor
 ******************************************************************************/

BraitenbergVehicle::BraitenbergVehicle() :
  light_sensors_(), wheel_velocity_(), wheel_velocities_(), light_behavior_(),
  food_behavior_(), bv_behavior_(), closest_light_entity_(NULL),
  closest_food_entity_(NULL), closest_bv_entity_(NULL), defaultSpeed_(5.0),
  collision_counter_(0), collision_mode_(false), observer_collection_(),
  food_counter_(0) {
  wheel_velocities_ = std::vector<WheelVelocity>(3);
  observer_collection_ = std::vector<Observer*>(1);
  set_type(kBraitenberg);
  motion_behavior_ = new MotionBehaviorDifferential(this);
  light_sensors_.push_back(Pose());
  light_sensors_.push_back(Pose());
  set_color(BRAITENBERG_COLOR);
  set_pose(ROBOT_INIT_POS);

  wheel_velocity_ = WheelVelocity(0, 0);

  // Set ID
  count++;
  set_id(count);
}

void BraitenbergVehicle::TimestepUpdate(unsigned int dt) {
  if (is_moving()) {
    motion_behavior_->UpdatePose(dt, wheel_velocity_);
  }
  UpdateLightSensors();
}

void BraitenbergVehicle::HandleCollision(EntityType ent_type,
                                         __unused ArenaEntity * object) {
  if (ent_type == kFood) {
    ConsumeFood();
  } else if (ent_type == kLight || ent_type == kUndefined) {
    return;
  } else if (ent_type == kPredator) {
    return;
  } else {
    set_heading(static_cast<int>((get_pose().theta + 180)) % 360);
    collision_mode_ = true;
  }
}

void BraitenbergVehicle::SenseEntity(const ArenaEntity& entity) {
  const ArenaEntity** closest_entity_ = NULL;
  if (entity.get_type() == kLight) {
    closest_entity_ = &closest_light_entity_;
  } else if (entity.get_type() == kFood) {
    closest_entity_ = &closest_food_entity_;
  } else if (entity.get_type() == kBraitenberg) {
    closest_entity_ = &closest_bv_entity_;
  // } else if (entity.get_type() == kPredator) {
  //   Predator temp =
  //     static_cast<ArenaMobileEntity>(static_cast<Predator>(entity));
  //   switch (temp.get_disguised_type()) {
  //     case (kLight):
  //       closest_entity_ = &closest_light_entity_;
  //       break;
  //     case (kFood):
  //       closest_entity_ = &closest_food_entity_;
  //       break;
  //     case (kBraitenberg):
  //     case (kPredator):
  //     default:
  //       closest_entity_ = &closest_bv_entity_;
  //   }
  }

  if (!closest_entity_) {
    return;
  }

  if (!*closest_entity_) {
    *closest_entity_ = &entity;
  }

  double distance = (this->get_pose()-entity.get_pose()).Length();
  double closest_distance =
  (this->get_pose()-(*closest_entity_)->get_pose()).Length();
  if (distance < closest_distance) {
    *closest_entity_ = &entity;
    closest_distance = distance;
    if (closest_distance > 100.0) {
      *closest_entity_ = NULL;
    }
  }

  /*
  // Check distances and set color accordingly

  // potential for future iterations

  const ArenaEntity** food_entity_ = &closest_food_entity_;
  const ArenaEntity** light_entity_ = &closest_light_entity_;

  double food_dis =
    (this->get_pose()-(*food_entity_)->get_pose()).Length();
  double lgt_dis =
    (this->get_pose()-(*light_entity_)->get_pose()).Length();

  if (food_dis < 100.0 && lgt_dis < 100.0) { // Both
    this->set_color(RgbColor(kMaroon));
  }
  else if (food_dis < 100.0 && lgt_dis > 100.0) { // Food
    this->set_color(RgbColor(kBlue));
  }
  else if (food_dis > 100.0 && lgt_dis < 100.0) { // Light
    this->set_color(RgbColor(kGold));
  }
  else { // None
    this->set_color(RgbColor(kMaroon));
  }
  */
}

void BraitenbergVehicle::Update() {
  if (food_counter_ >= 600) {
    // TODO(joh13124): Die, break
    Die();
    return;
  }
  food_counter_++;

  if (!collision_mode_) {  // not colliding with anything,normal
    WheelVelocity light_wheel_velocity = WheelVelocity(0, 0);

    int numBehaviors = 3;

    int food = 1;  // track if food behavior
    int light = 1;  // track if light behavior

    if (light_behavior_->GetBehaviorType() != kNone) {
      light_wheel_velocity =
        light_behavior_->UpdateWheel(
          get_sensor_reading_right(closest_light_entity_),
          get_sensor_reading_left(closest_light_entity_),
          defaultSpeed_);
    } else {
      numBehaviors--;
      light = 0;
    }

    wheel_velocities_[0] = light_wheel_velocity;

    WheelVelocity food_wheel_velocity = WheelVelocity(0, 0);

    if (food_behavior_->GetBehaviorType() != kNone) {
      if (food_counter_ < 400) {
      food_wheel_velocity =
        food_behavior_->UpdateWheel(
          get_sensor_reading_right(closest_food_entity_),
          get_sensor_reading_left(closest_food_entity_),
          defaultSpeed_);
      } else {
        AggressiveBehavior * behavior = new AggressiveBehavior();
        food_wheel_velocity = behavior->UpdateWheel(
          get_sensor_reading_right(closest_food_entity_),
          get_sensor_reading_left(closest_food_entity_), defaultSpeed_);
        delete behavior;
      }
    } else {
      numBehaviors--;
      food = 0;
    }

    wheel_velocities_[1] = food_wheel_velocity;

    WheelVelocity bv_wheel_velocity = WheelVelocity(0, 0);

    if (bv_behavior_->GetBehaviorType() != kNone) {
      bv_wheel_velocity =
        bv_behavior_->UpdateWheel(
          get_sensor_reading_right(closest_bv_entity_),
        get_sensor_reading_left(closest_bv_entity_), defaultSpeed_);
    } else {
      numBehaviors--;
    }

    wheel_velocities_[2] = bv_wheel_velocity;

    if (numBehaviors) {
      wheel_velocity_ = WheelVelocity(
        (light_wheel_velocity.left + (food_wheel_velocity.left*food_counter_) +
          bv_wheel_velocity.left)/numBehaviors,
        (light_wheel_velocity.right +
        (food_wheel_velocity.right*food_counter_) +
          bv_wheel_velocity.right)/numBehaviors,
        defaultSpeed_);
    } else {
      wheel_velocity_ = WheelVelocity(0, 0);
    }

    if ((food == 1 && light == 1) ||
       (food == 0 && light == 0)) {  // both or none
      this->set_color(RgbColor(kMaroon));
    } else if (food == 0 && light == 1) {  // light
      this->set_color(RgbColor(kGold));
    } else {
      this->set_color(RgbColor(kBlue));  // food
    }
  } else {  // in collision mode
    if (collision_counter_ < 20) {
      wheel_velocity_ = WheelVelocity(5, 5, defaultSpeed_);
      collision_counter_++;
    } else {
      collision_mode_ = false;
      collision_counter_ = 0;
      set_heading(static_cast<int>((get_pose().theta + 180)) % 360);
      set_heading(static_cast<int>((get_pose().theta + 45)) % 360);
    }
  }

  Notify();
}

std::string BraitenbergVehicle::get_name() const {
  return "Braitenberg " + std::to_string(get_id());
}

std::vector<Pose> BraitenbergVehicle::get_light_sensors_const() const {
  return light_sensors_;
}

std::vector<Pose> BraitenbergVehicle::get_light_sensors() {
  return light_sensors_;
}

double BraitenbergVehicle::get_sensor_reading_left(const ArenaEntity* entity) {
  if (entity) {
    return 1800.0/std::pow(
      1.08, (entity->get_pose()-light_sensors_[0]).Length());
  }

  return 0.0001;
}

double BraitenbergVehicle::get_sensor_reading_right(const ArenaEntity* entity) {
  if (entity) {
    return 1800.0/std::pow(
      1.08, (entity->get_pose()-light_sensors_[1]).Length());
  }

  return 0.0001;
}

void BraitenbergVehicle::UpdateLightSensors() {
  for (unsigned int f = 0; f < light_sensors_.size(); f++) {
    Pose& pos = light_sensors_[f];
    if (f == 0) {
      pos.x = get_pose().x + get_radius() * cos(deg2rad(
        get_pose().theta - 40));
      pos.y = get_pose().y + get_radius() * sin(deg2rad(
        get_pose().theta - 40));
    } else {
      pos.x = get_pose().x + get_radius() * cos(deg2rad(
        get_pose().theta + 40));
      pos.y = get_pose().y + get_radius() * sin(deg2rad(
        get_pose().theta + 40));
    }
  }
}

void BraitenbergVehicle::LoadFromObject(json_object * entity_config_pointer) {
  json_object& entity_config = *entity_config_pointer;
  ArenaEntity::LoadFromObject(&entity_config);

  if (entity_config.find("light_behavior") != entity_config.end()) {
    set_light_behavior(get_behavior_type(
      entity_config["light_behavior"].get<std::string>()));
  }
  if (entity_config.find("food_behavior") != entity_config.end()) {
    set_food_behavior(get_behavior_type(
      entity_config["food_behavior"].get<std::string>()));
  }
  if (entity_config.find("robot_behavior") != entity_config.end()) {
    set_bv_behavior(get_behavior_type(
      entity_config["robot_behavior"].get<std::string>()));
  }

  UpdateLightSensors();
}

void BraitenbergVehicle::Notify() {
  for (unsigned int i = 0; i < observer_collection_.size(); i++) {
    if (observer_collection_[i] != nullptr) {
      observer_collection_[i]->Update(wheel_velocities_);
    }
  }
}

void BraitenbergVehicle::Subscribe(Observer * observer) {
  observer_collection_.push_back(observer);
  observer->UpdateSub(this);
}

void BraitenbergVehicle::Unsubscribe(Observer * observer) {
  observer_collection_.clear();
  observer->UpdateSub(nullptr);
}

void BraitenbergVehicle::Die() {
  set_type(kUndefined);
  set_mobility(false);
  set_color(RgbColor(220, 220, 220));
  wheel_velocity_ = WheelVelocity(0, 0);
}

NAMESPACE_END(csci3081);
