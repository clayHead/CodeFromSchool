### Partial Assessment for Project Iteration 03 - Prelim-1_Code (Graded By: Shruti Verma)

#### Total score: _0_ / _0_

Run on May 14, 19:19:29 PM.


#### Prelim1 Release Branch

+ Pass: Checkout prelim 1 branch.




#### System Files and Lab Directory Structure

+ Pass: Copy directory "Files for Dependencies".



+ Pass: Check that directory "project" exists.

+ Pass: Check that directory "project/src" exists.

+ Pass: Copy directory "Files for Testing".



+ Pass: Change into directory "project".

+ Pass: Checkout regrade branch.




#### Implementation Effort

+ Pass: Graded on Canvas.




#### Decorator Design

+ Pass: Graded on Canvas.



#### Total score: _0_ / _0_

