Start with the coffee example to understand the decorator pattern.
Then convert the UMNPerson example to a decorator pattern implementation.
