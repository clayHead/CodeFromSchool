#include "robot.h"
#include "legged_robot.h"
#include <stdio.h>

class Factory_pointer { // Pass in pointer and intialize robot
    public:
        void create(Robot **r) {
            printf("Creating Robot");

            *r = new Robot();
        }
        void create(LeggedRobot **&r) {
            printf("Creating Robot");
            
            *r = new LeggedRobot();
        }
}