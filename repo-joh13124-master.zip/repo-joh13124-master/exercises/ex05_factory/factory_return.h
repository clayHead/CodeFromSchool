#include "robot.h"
#include "legged_robot.h"
#include <stdio.h>

class Factory_pointer { // Pass in nothing and return robot
    public:
        Robot * create() {
            
        }
}