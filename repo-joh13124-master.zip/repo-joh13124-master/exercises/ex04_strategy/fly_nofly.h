#ifndef FLY_NOFLY_H_
#define FLY_NOFLY_H_

#include <iostream>
#include <cstdlib>

#include "fly.h"

class NoFly : public FlyBehavior {
public:
  // cannot fly <<<<<<<<<<<<<<<<<<<<<<<<<<< Complete these methods;
  NoFly() {}
  void Fly() {}
};

#endif
