#ifndef DUCK_MALLARD_H_
#define DUCK_MALLARD_H_

#include "duck.h"

class Mallard : public Duck {
public:
  Mallard();
  void Display();
};

#endif
