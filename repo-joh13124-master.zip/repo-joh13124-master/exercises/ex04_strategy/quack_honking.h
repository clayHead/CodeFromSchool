#ifndef QUACK_HONKING_H_
#define QUACK_HONKING_H_

#include <iostream>
#include <cstdlib>

#include "quack.h"

class Honking : public QuackBehavior {
public:
  // This is a confused swan that honks instead of quacks.
  // Complete these methods. <<<<<<<<<<<<<<<<
  Honking() {}
  void Quack() {}
};

#endif
