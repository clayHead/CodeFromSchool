#ifndef DUCK_RUBBERDUCK_H_
#define DUCK_RUBBERDUCK_H_

#include "duck.h"

class RubberDuck : public Duck {
public:
  RubberDuck();
  void Display();
};

#endif
