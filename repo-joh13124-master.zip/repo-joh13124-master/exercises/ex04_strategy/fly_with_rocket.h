#ifndef FLY_WITH_ROCKET_H_
#define FLY_WITH_ROCKET_H_

#include <iostream>
#include <cstdlib>

#include "fly.h"

class FlyWithRocket : public FlyBehavior {
  // Can fly REALLY fast - don't use the default speed <<<<<<<<<<
  // Complete these methods.
  FlyWithRocket() {}
  void Fly() {}
};

#endif
