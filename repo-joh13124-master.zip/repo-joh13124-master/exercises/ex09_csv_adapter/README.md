This isn't really an exercise. It is an example of how to convert/adapt a csv formatted configuration file into a json formatted file.
