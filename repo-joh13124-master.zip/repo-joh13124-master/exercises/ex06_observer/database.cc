#include <iostream>

#include "database.h"

void Database::Update(const State& state) {
  // FILL THIS IN
}

void Database::Save() {
  // ?? FAKE SAVE -- can print something out to report save.
}
