#include <iostream>

#include "state.h"
#include "weather.h"
#include "viewer.h"
#include "database.h"

int main() {
  // Instantiate Weather, Viewer, Database.
  // Register Observers with Subject

  while (true) {
    // Enter in -100 when you want to quit
    // Uncomment this when above is complete
    /*
    if (0 == weather->TakeMeasurements()) {
      return 1;
    }
    */
  }
}
