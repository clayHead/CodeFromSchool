### Partial Assessment for Project Iteration 02 - Final-Code (Graded By: Shruti Verma)

#### Total score: _5.0_ / _16_

Run on May 06, 18:10:53 PM.


#### Release Branch

+ Pass: Checkout release branch.




#### System Files and Lab Directory Structure

+ Pass: Copy directory "Files for Dependencies".



+ Pass: Check that directory "project" exists.

+ Pass: Check that directory "project/src" exists.

+ Pass: Copy directory "Files for Testing".



+ Pass: Change into directory "project".


#### Feature Testing


#### Compile Tests

+ Pass: Clean project.



+ Pass: Check that make compiles.



+ Pass: Check that file "build/bin/arenaviewer" exists.

+ Pass: Change into directory "tests-i".

+ Pass: Check that make compiles.



+ Pass: Change into directory "..".

+ Pass: Check that file "./build/bin/tests-i" exists.

+  _3_ / _3_ : Pass: Ability to select and change behaviors? (light, food, robot)



+  _0_ / _4_ : Fail: Does the Predator kill the Robot? Is the Robot now a ghost?
    fails to run the test executable: InteractiveTest.ArenaViewerTest.
arg  1 = scenes/kill_robot.json
Note: Google Test filter = InteractiveTest.ArenaViewerTest
[==========] Running 1 test from 1 test suite.
[----------] Global test environment set-up.
[----------] 1 test from InteractiveTest
[ RUN      ] InteractiveTest.ArenaViewerTest
FATAL: Bad entity type on creation

return code: -6



+  _0_ / _4_ : Fail: Does the Robot starve to death? Is the Robot now a ghost?
<pre>
<b>The interactive test failed.</b></pre>




#### Code Inspection

+  _2.0_ / _5_ : Pass: Robot WheelVelocities are being calculated dynamically.

    <pre>the velocity should take BV behavior too into account while calculating wheel velocity. It should use dynamic weighting to calculate the final velocity</pre>

#### Total score: _5.0_ / _16_

