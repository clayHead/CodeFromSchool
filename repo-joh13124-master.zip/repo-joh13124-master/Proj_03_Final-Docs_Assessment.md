### Partial Assessment for Project Iteration 03 - Final-Docs (Graded By: Shruti Verma)

#### Total score: _0_ / _0_

Run on May 10, 11:44:10 AM.


#### Release Branch

+ Pass: Checkout release branch.




#### System Files and Lab Directory Structure

+ Pass: Copy directory "Files for Dependencies".



+ Pass: Check that directory "project" exists.

+ Pass: Check that directory "project/src" exists.

+ Pass: Copy directory "Files for Testing".



+ Pass: Change into directory "project".


#### Design

+ Fail: Check that file "docs/iteration3_design.pdf" exists.

     "docs/iteration3_design.pdf" not found.


<pre>Graded on Canvas - check Canvas rubric for results.</pre>


#### Doxygen


<pre>Graded on Canvas - check Canvas rubric for results.</pre>

+ Pass: Documentation builds.



+ Fail: Check that file "docs/html/index.html" exists.

     "docs/html/index.html" not found.

+ Pass: Check that file "src/mainpage.h" exists.

+ Fail: Graded on Canvas.

<pre>Cannot find file.</pre>



#### Total score: _0_ / _0_

