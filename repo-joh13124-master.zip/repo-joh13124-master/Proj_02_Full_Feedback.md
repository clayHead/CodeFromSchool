### Feedback for Proj 02

Run on April 15, 23:57:44 PM.

+ Pass: Checkout devel branch.



+ Pass: Report branch name.




#### System Files and Lab Directory Structure

+ Pass: Copy directory "Files for Dependencies".



+ Pass: Check that directory "project" exists.

+ Pass: Check that directory "project/src" exists.

+ Pass: Copy directory "Files for Testing".



+ Pass: Change into directory "project".


#### Compile Tests

+ Pass: Clean project.



+ Pass: Check that make compiles.



+ Pass: Check that file "build/bin/arenaviewer" exists.


#### Documentation Tests

+ Pass: Documentation builds.



+ Pass: Check that file "docs/html/index.html" exists.


#### Git Usage

+ Pass: Check git commit history
Commits found=63

+ Pass: Run git ls-remote gather all branches in repo

87469a294a0e43a79dee70e3abc1683ec9cc07e3	refs/heads/Factory_unit_tests

78904e89ae38d161e591295941203a3e04f11647	refs/heads/ObserverPattern

288ab001d12ff5a837c4fb1d6706a7e600d8f7f0	refs/heads/Tests

a4741d2e05a68ebf9472e61fe5d3a588ba87cc8c	refs/heads/Working_srategy_pattern

fc6ced82fb6c798df0b28c3ed3c6c0817570b1a4	refs/heads/devel

85025651575170221b6970108c0a36a7d00cdc95	refs/heads/exercise5

043c01af6e510a368db0a2a97f9ed30ec0404bbd	refs/heads/feature_enhancements

9d421f379090f6bde654a09c5f8212e5fe8d0336	refs/heads/fix/01-compilation-errors

21fa49d161366253316353d1258a1fa3b685a8c1	refs/heads/fix/02-robot-overlap2

051d37909d534b8188b2a6950fe20c8fcf8def65	refs/heads/fix/05-final-documentation

79c73f425149edb46ae2c75f97f3ff8a5d4b4850	refs/heads/it2pri1

3f05e8631c2bef3fea7760efcd9009df21ffe12a	refs/heads/master

029b323fe4ef701df43190d557d3baeea9b7783b	refs/heads/pre-release/iteration1

81ec72f53d3c28e123c5c6c93ac7bed1304e6cbe	refs/heads/predator

d4b029ea0ce7adb9cc9989dcb413623156c078b1	refs/heads/release/iteration1

907c074e384f7eadecd56ae9e5bb58061b8e6402	refs/heads/release/iteration2-prelim1

81b10922e84a4f9007eb56cad4383f72e89b0993	refs/heads/release/iteration2-prelim2

a2b8912bcb1d73d3340a6f2d1c8dfa8c7193d50e	refs/heads/strategy_patern




#### Git Issue Usage

+ Pass: Configuring GHI

+ Pass: Run ghi for total number of open issues in Github repo (Found: 1)

[OPEN issue #12] :  Dynamic Color changing





+ Pass: Run ghi for total number of closed issues in Github repo (Found: 19)

[CLOSED issue #21] :  Bv's dont interact with predators

[CLOSED issue #20] :  Bv's colliding with iight

[CLOSED issue #19] :  Predators dont move 1

[CLOSED issue #18] :  Bv wont change color after starving

[CLOSED issue #17] :  Bv will move after dying

[CLOSED issue #16] :  BV will stop when colliding with food 1

[CLOSED issue #15] :  Fix memory leak when changing behavior

[CLOSED issue #14] :  Fix(): Stratgey Pattern ↑

[CLOSED issue #13] :  Strategy patern ↑

[CLOSED issue #11] :  Improved Design

[CLOSED issue #10] :  Google style 1

[CLOSED issue #9] :  Color Change 1

[CLOSED issue #8] :  Robot Collision 1

[CLOSED issue #7] :  Tests ↑

[CLOSED issue #6] :  Changed names and locations of pdfs for feedback ↑

[CLOSED issue #5] :  Feature enhancements ↑

[CLOSED issue #4] :  fix(factory classes): Fixed small mistakes in classes ↑

[CLOSED issue #3] :  Tests: Added factory classes for each of the arena entities ↑

[CLOSED issue #1] :  Fixed compliation errors for project. ↑






#### Style Tests

+ Pass: Ensuring code follows style guide.




#### Unit Tests

+ Pass: Check that file "build/bin/unittest" exists.

+ Pass: Check that a GoogleTest test passes.
    passes the test: InstProj02.TestsRun.



