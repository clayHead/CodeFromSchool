### Partial Assessment for Project Iteration 02 - Prelim-2-Style (Graded By: Nikki Kyllonen)

#### Total score: _5_ / _5_

Run on May 07, 12:11:05 PM.


#### Prelim2 Release Branch

+ Pass: Checkout prelim release branch.




#### System Files and Lab Directory Structure

+ Pass: Copy directory "Files for Dependencies".



+ Pass: Check that directory "project" exists.

+ Pass: Check that directory "project/src" exists.

+ Pass: Copy directory "Files for Testing".



+ Pass: Change into directory "project".


#### Style Tests

+  _5_ / _5_ : Pass: Grading style compliancy errors (Found: 0 errors)

#### Total score: _5_ / _5_

