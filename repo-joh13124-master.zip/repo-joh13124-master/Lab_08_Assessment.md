### Assessment for Lab 08

#### Total score: _100_ / _100_

Run on February 25, 15:03:56 PM.


#### System Files and Directory Structure

+ Pass: Check that directory "labs" exists.

+ Pass: Check that directory "labs/lab08_gdb" exists.

+ Pass: Change into directory "labs/lab08_gdb".

+  _10_ / _10_ : Pass: Replace doInterestingThing(1999); with doInterestingThing(1999);doInterestingThing(2018); in main.cc.




#### Test that code compiles and creates the exectuable

+  _30_ / _30_ : Pass: Check that make compiles.



+  _10_ / _10_ : Pass: Check that file "date" exists.


#### Test Output Execution

+  _10_ / _10_ : Pass: Program executes flawlessly.



+  _5_ / _5_ : Pass: Check for correct output.

    Complete.



+ Pass: Replace i <= with i < in main.cc.



+ Pass: Check that make compiles.



+  _20_ / _20_ : Pass: Most of the program works.



+  _15_ / _15_ : Pass: Check for correct output.

    Complete.



#### Total score: _100_ / _100_

