### Partial Assessment for Project Iteration 01 - Combined (Graded By: 3081 TA's)

#### Total score: _4.375_ / _15_

Run on April 05, 14:38:49 PM.


### Partial Combined Scores (15% of the Iteration 1 Grade)

+  _4.375_ / _5_ : Pass: [Design & Documentation + Features](Proj_01_DesignDoc_Assessment.md) - 5%



+  _0_ / _10_ : Fail: [Factory & Tests + Features](Proj_01_FactoryTests_Assessment.md) - 10%

<pre>Not Graded
</pre>




[View Git Partial Feedback](Proj_01_GitPartial_Assessment.md)

#### Total score: _4.375_ / _15_

