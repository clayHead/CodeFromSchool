# 4061-proj5
Synchronization

## Members

| Member Name | x500   |
|-------------|--------|
| Chase       |joh13266|
| Clayton     |joh13124|
| Modou       |jawxx001|

## Contributions

| Member Name | Contribution |
|-------------|--------------|
| Modou       |Bulk of code|
| Chase       |Assited in code|
| Clayton     |Readme and testing|

## Known Bugs
No Known Bugs

## Test Cases Used
Number of threads greater than one and less than 16.
Takes input file and reads lines once across three threads
These are inputed into a linked list.
Ex input and output
Alpha
Bravo
Charlie
Delta

0, 0, Alpha
3, 1, Bravo
2, 2, Charlie
1, 3, Delta

## Extra Credit
False
