CSCI 5081
Team#20
Scott Reisdorf, David Czaia, Clayton Johnson, Tyler Deng

Specific instructions for running the program:
