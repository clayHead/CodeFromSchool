import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class VotingProgram {
    public static void main(String[] args) {

        StandardGUI gui = new StandardGUI();

    }
}
