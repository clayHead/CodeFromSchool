import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class StandardGUI extends JFrame implements ActionListener {

    private File file;

    //GUI components
    //labels
    private JLabel welcome = new JLabel("Welcome to Voters 'R us");
    private JLabel instructions = new JLabel("Please select a file with voting information to run");

    //file chooser/browser
    private JFileChooser chooser = new JFileChooser();

    //buttons
    private JButton selectFile = new JButton("Select File");
    private JButton exitButton = new JButton("Exit");

    //panels
    private JPanel topPanel = new JPanel(new GridLayout(2,1));
    private JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

    //Getter for file

    /**
     * getFile
     * This method provides access to the private instance of file
     * @return File getter for file
     */
    public File getFile(){
        return this.file;
    }

    /**
     * StandardGUI
     * Constructor for StandardGUI class which creates the instance of a GUI for the voting program
     */
    public StandardGUI(){
        setTitle("Voters 'R us");
        setSize(450,200);
        setMaximumSize(new Dimension(450,200));
        setMinimumSize(new Dimension(450,200));
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(2,1));
        setVisible(true);
        addComponents();
    }

    /**
     * addComponents
     * This adds all the buttons, panels, and other components to the JFrame of the
     * GUI when it is instantiated.
     */
    private void addComponents(){
        topPanel.add(welcome);
        topPanel.add(instructions);
        bottomPanel.add(selectFile);
        selectFile.setSize(100,50);
        selectFile.addActionListener(this);
        add(topPanel);
        add(bottomPanel);
    }

    /**
     *
     * @param e event that was triggered
     * Checks for the button that was pressed, their is only the
     * Select FIle button so if that was what triggered it, it will open up
     * the JFileChoser dialog box and allow the user to browse their computer
     * for a file.
     */

    @Override
    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();

        if(actionCommand.equals("Select File")){
            int fileOpened = chooser.showOpenDialog(this);
            if(fileOpened == JFileChooser.APPROVE_OPTION){
                file = chooser.getSelectedFile();
                ResultsGUI results = new ResultsGUI(file);
                this.dispose();
            }
        }
    }
}


