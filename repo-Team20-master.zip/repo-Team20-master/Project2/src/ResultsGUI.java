import javax.print.attribute.standard.JobName;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class ResultsGUI extends JFrame implements ActionListener {

    //plain text display for election results
    private String filler = "Election results will be displayed here"; //filler text for before it is run
    private JTextArea resultsText = new JTextArea(30,30);
    private JScrollPane final_text = new JScrollPane(resultsText); //makes the text box editable
    private File electionFile;
    
    // Audit information stored from election
    private java.util.List<String> auditResults;

    //buttons
    private JButton runbutton = new JButton("Run Election");
    private JButton saveButton = new JButton("Save audit file");
    private JButton closeButton = new JButton("Exit");
    private JButton newFileButton = new JButton("Select Different File");

    JFileChooser fileChooser = new JFileChooser();

    //panels
    private JPanel leftPanel = new JPanel(new GridLayout(3,1));
    private JPanel rightPanel = new JPanel();
    private JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

    /**
     * getResultsText
     * This is a getter method for the results text (where results are outputted)
     * @return JTextArea getter for text area
     */
    public JTextArea getResultsText(){
        return resultsText;
    }
    /**
     * ResultsGUI
     * @param file is the election file that was chosen by StandardGui
     * Constructor for ResultsGUI class which creates the instance of a GUI for the voting program
     */
    public ResultsGUI(File file){
        this.electionFile = file;
        setTitle("Voters 'R us");
        setSize(800,550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(1,2));
        addComponents();
        setVisible(true);
        if(!checkFile()){
            runbutton.setVisible(false);
            newFileButton.setVisible(true);
            resultsText.setText("INCORRECT FILE FORMAT:\nPlease Select a file with election type as first line.");
        }
    }
    /**
     * addComponents
     * This adds all the buttons, panels, and other components to the JFrame of the
     * GUI when it is instantiated.
     */
    private void addComponents(){
        resultsText.setText(filler);

        //add action listeners to buttons
        runbutton.addActionListener(this);
        closeButton.addActionListener(this);
        saveButton.addActionListener(this);
        newFileButton.addActionListener(this);
        //set visible status
        saveButton.setVisible(false);
        //format components
        runbutton.setSize(100, 50);
        closeButton.setSize(100,50);

        //adding to buttons to panels
        topPanel.add(runbutton);
        topPanel.add(saveButton);
        topPanel.add(newFileButton);
        topPanel.add(closeButton);
        leftPanel.add(topPanel);
        resultsText.setEditable(false);
        rightPanel.add(final_text);

        //add components to JFrame
        add(leftPanel);
        add(rightPanel);
    }


    /**
     * checks first line of file for election type
     * @return boolean value for whether or not file has OPL or CPL on first line
     */
    public boolean checkFile(){
        try {
            Scanner scanner = new Scanner(this.electionFile);


            String electionType = "";
            if (scanner.hasNextLine()) {
                electionType = scanner.nextLine();
            } else {
                this.resultsText.setText("File is empty");
                return false;
            }
            if (!electionType.equals("OPL") && !electionType.equals("CPL")) {
                this.resultsText.setText("Please Select a file with election type as first line.");
                return false;
            }
            else {
                resultsText.setText(filler);
            }
        return true;
        }
        catch (IOException except){
            except.printStackTrace();
            return false;
        }
    }

    /**
     * actionPerformed
     * @param e is an ActionEvent object corresponding to a button press on the GUI.
     * This function contains the logic for "Run Election", "Exit", "Select Different File", and "Save Audit File"
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();

        //if statements to see which button was pressed
        if(actionCommand.equals("Run Election")) {
            try {
                Scanner scanner = new Scanner(this.electionFile);


                String electionType = "";
                if (scanner.hasNextLine()) {
                    electionType = scanner.nextLine();
                } else {
                    System.out.println("File is empty");
                }
                if (electionType.equals("OPL")) {
                    OPL election = new OPL();
                    election.run(electionFile);
                    String results = election.getResultsString();
                    resultsText.setText(results);
                    auditResults = election.getAuditFile();
                    saveButton.setVisible(true);
                } else if (electionType.equals("CPL")) {
                    CPL election = new CPL();
                    election.run(electionFile);
                    String results = election.getResultsString();
                    resultsText.setText(results);
                    auditResults = election.getAuditFile();
                    saveButton.setVisible(true);
                } else {
                    resultsText.setText("Election type is not OPL or CPL");
                }
            }
            catch (IOException except){
                except.printStackTrace();
            }
        }
        else if(actionCommand.equals("Exit")){
            this.dispose();
            System.exit(0);
        }
        else if(actionCommand.equals("Select Different File")){
            JFileChooser chooser = new JFileChooser();
            int fileOpened = chooser.showOpenDialog(this);
            if(fileOpened == JFileChooser.APPROVE_OPTION){
                electionFile = chooser.getSelectedFile();
                if(checkFile()){
                    saveButton.setVisible(false);
                    runbutton.setVisible(true);
                }
                else{
                    runbutton.setVisible(false);
                    saveButton.setVisible(false);
                    resultsText.setText("INCORRECT FILE FORMAT:\nPlease Select a file with election type as first line.");
                }
            }
        }
        else if(actionCommand.equals("Save audit file")){
            JFileChooser chooser = new JFileChooser();
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    	    chooser.setDialogTitle("Select Location to store audit file.");
    	    if (chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
    	    	File file = chooser.getSelectedFile();
    	    	String test = file.getAbsolutePath();
    	    	System.out.println(test.substring(test.length()-4, test.length()));
    	    	if (!test.substring(test.length()-4, test.length()).equals(".txt")) {
    	    		resultsText.append("\nNo file name entered. Defaulting to 'Audit.txt'");
    	    		file = new File(chooser.getSelectedFile() + File.separator + "Audit.txt");
    	    	}
    	    	// Create file at location and convert to path for writing
    	    	Path auditPath = file.toPath();
    	    	  
    	    	// Write to path
    	    	try {
					Files.write(auditPath, auditResults);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
    	    }
    	    else {
    	      System.out.println("No Selection ");
    	    }
        }
    }
}
