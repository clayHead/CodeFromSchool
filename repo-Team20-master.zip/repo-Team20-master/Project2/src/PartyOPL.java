import java.util.*;

public class PartyOPL {
    private Map<String,Integer> candidates = new HashMap(); // key is candidate name, value is the number of votes
    boolean sorted = false;
    List<Map.Entry<String,Integer>> candidatesList;

    /**
     *
     * @return String that explains how many votes each candidate in the party got
     */
    public String toString(){
        String candidateInfo = new String();
        for(Map.Entry<String, Integer> entry : candidates.entrySet()) {
            candidateInfo = candidateInfo + entry.getKey() + " received " + entry.getValue() + " vote(s)\n";
        }
        return candidateInfo;
    }

    /**
     *
     * @return a boolean that represents whether or not the party has any more candidates
     */
    public boolean hasMoreCandidates() {
        if (!sorted) {
            candidatesList = new ArrayList(candidates.entrySet());
            Collections.sort(candidatesList, Comparator.comparing(Map.Entry::getValue)); //sorts the remainders
            sorted = true;
        }
        System.out.println("SIZE IS " + candidatesList.size());
        return candidatesList.size() > 0;
    }

    /**
     *
     * @param name Name of the candidate in which a vote should be registered for.
     * Function will add a vote for that candidate within the party hashmap.
     */
    public void addVote(String name) {
            candidates.put(name,candidates.get(name)+1); // adds 1 to number of votes for that candidate
    }
    /**
     *
     * @param name name of the candidate to add
     * Adds the name of teh candidate to the party
     */
    public void addCandidate(String name) {
        candidates.put(name,0);
    }

    /**
     *
     * @param tiedCandidates List of candidates which are tied for most votes
     * @return randomly chosen candidate with max number of votes
     */
    public String coinFlip(List<String> tiedCandidates) {
            Random rand = new Random();
            int randChoice = rand.nextInt(1000);
            for(int i = 0; i < 100; i++) {//call java's random generator several times to increase randomness
                randChoice = rand.nextInt(1000);
            }
            String chosenCandidate = tiedCandidates.get(randChoice%tiedCandidates.size());
            for (Map.Entry <String,Integer> entry : candidatesList) { // removes the candidate from the candidates list
                if (entry.getKey().equals(chosenCandidate)) {
                    candidatesList.remove(entry);
                    System.out.println("REMOVED in tie");
                    break;
                }
            }
            return chosenCandidate;
    }

    /**
     *
     * @param candidatesList List of all the candidates
     * @return the candidates which are tied for the most number of votes
     */
    public List<String> tiedCandidates(List<Map.Entry<String,Integer>> candidatesList) {
        List<String> tiedCandidates = new ArrayList();
        int currentValue = candidatesList.get(candidatesList.size()-1).getValue();
        for (int i = candidatesList.size()-1;i>=0;i--) { // go through the candidate list and see which ones are tied for the current value
            if (candidatesList.get(i).getValue() == currentValue) {
                tiedCandidates.add(candidatesList.get(i).getKey());
            }
            else {
                break;
            }
        }
        return tiedCandidates;
    }
    /**
     *
     * @return the name of the candidate with the most votes in the party that has not already been selected.
     */
    public String getNextCandidate() {
        List<String> tiedCandidates = tiedCandidates(candidatesList);
        String candidateName;
        if (tiedCandidates.size()==1) { // if one candidate then we just return it and remove it so we don't get it again
            Map.Entry<String, Integer> candidate = candidatesList.get(candidatesList.size()-1);
            candidateName = candidate.getKey();
            candidatesList.remove(candidate);
            System.out.println("Candidate removed here");
        }
        else { // otherwise we choose a random candidate to return amongst the tied candidates
            candidateName = coinFlip(tiedCandidates);
        }
        return candidateName;
    }
    //GETTER FOR TESTING
    public String getCoinFlip(List<String> tiedCandidates){
        return coinFlip(tiedCandidates);
    }

    Map<String,Integer> getCandidates() {
        return this.candidates;
    }
}
