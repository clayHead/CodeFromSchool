import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;

public class OPL {
    private int numSeats = 0;
    private int numBallots = 0;
    private int numCandidates = 0;
    private int seatsFilled = 0;
    private Path auditFile;
    private List<String> auditInfo = new ArrayList();
    private Map<String,Integer> partyVotes = new HashMap(); // stores the party letter as key and numVotes as value
    private Map<String,PartyOPL> partyObjects = new HashMap(); //stores the party letter as key and party object as value
    private List<Candidate> candidates = new ArrayList();
    private Map<String,List<String>> winners = new HashMap();
    private String resultsString = new String();
    private List<String> auditString = new ArrayList();
    
    /**
     * Getter to let the results GUI save the results of the Audit
     * @return Audit file results as a String
     */
    List<String> getAuditFile() { return auditString; }
    
    //getter for resultsString
    public String getResultsString() { return resultsString; }

    /**
     *
     * @param tiedParties list of parties that are tied and have candidates left
     * @param seatsNeeded number of seats we have left to fill
     * This method is for deciding tie breakers between parties.
     *      * It will randomly choose a party out of those tied and add to the parties who win the tie. It will then
     *                    remove it from parties under consideration and continue choosing winners until the amount of
     *                    seats needed is fulfilled
     * @return List of parties that won the tie
     */

    private List<String> coinFlip(List<String> tiedParties, int seatsNeeded){
        List<String> chosenParties =new ArrayList();
        int seatsAdded = 0;
        while (seatsNeeded!=seatsAdded) {
            Random rand = new Random();
            int randChoice = rand.nextInt(1000);
            for(int i = 0; i < 100; i++) {//call java's random generator several times to increase randomness
                randChoice = rand.nextInt(1000);
            }
            String addedParty = tiedParties.get(randChoice%tiedParties.size());
            chosenParties.add(addedParty);
            tiedParties.remove(addedParty);
            seatsAdded++;
        }
        return chosenParties;
    }

    /** writeToMedia
     * This method will create a media file for the media to use containing pertinent info
     * that they will want to show. It writes the total ballots cast, the number of seats
     * that were up for election, and the winners - both party and candidate winners with
     * number of votes received.
     */
    private void writeToMedia() {
       try {
           PrintStream console = System.out;
           PrintStream toMediaFile = new PrintStream(new File("Media.txt"));
           System.setOut(toMediaFile);
           System.out.println("A total of " + numBallots + " ballots were cast and " + numSeats + " seats were awarded.");
           System.out.println("WINNERS");
           for (Map.Entry<String, List<String>> entry : winners.entrySet()) {
               System.out.println("The " + entry.getKey() + " party gets " + entry.getValue().size() + " seats. They received overall " +
                       partyVotes.get(entry.getKey()) + " votes.");
               if (entry.getValue().size() != 0) {
                   System.out.println("These seats go to:");
                   for (String winner : entry.getValue()) {
                       System.out.println(winner);
                   }
               }
           }
           System.setOut(console);
           toMediaFile.close();
       } catch (IOException e){
           e.printStackTrace();
       }
    }

    /**
     * writeToAudit
     * This method creates an audit file with all of the information associated with the election
     * It outputs the type of election, the number of ballots, the number of available seats, the
     * number of candidates running for election, the candidates names and number of votes listed
     * by party, the number of votes each party got, and then it lists the winners by party, again
     * showing their votes. Lastly it will print every single vote cast by candidate name and their
     * party so that everything may be checked manually to assure the system is running fairly.
     *
     */
    private void writeToAudit() { //creating the formatting and adding to lists to make printing easier
        List<String> electionInfo = Arrays.asList("OPL Election", "Number of seats up for election: " + numSeats, "Number of ballots submitted: " + numBallots,
                "Number of candidates running: " + numCandidates, "Candidates: ");
        List<String> candidateInfo = new ArrayList<String>();
        for(Map.Entry<String, PartyOPL> entry : partyObjects.entrySet()){
            candidateInfo.add("//" + entry.getKey() + " Party received " + partyVotes.get(entry.getKey()) + " votes//\n");
            candidateInfo.add(entry.getValue().toString());
        }
        List<String> winningCandidates = new ArrayList<String>();
        winningCandidates.add("***WINNING CANDIDATES***\n");
        for(Map.Entry<String, List<String>> entry : winners.entrySet()){
            winningCandidates.add("From the " + entry.getKey() + " Party: \n");
            winningCandidates.add(entry.getValue().toString()+"\n");
        }
        winningCandidates.add("\n//ELECTION PROGRESSION BY VOTES//\n");
        List<String> output = new ArrayList<String>(electionInfo); //merge all of the different lists into one list for writing to the file
        output.addAll(candidateInfo);
        output.addAll(winningCandidates);
        output.addAll(auditInfo);
        auditString = output;
        try {
            Files.write(auditFile, output);
        } catch (IOException e){
            e.printStackTrace();
        }
    }
    /**
     @param partyObject The party object in which we will extract candidates from
     @param partySeats The number of seats that party won
     @param partyName The name of the party
     */
    public void addWinnersForParty(PartyOPL partyObject,int partySeats, String partyName) { // Will get and add the winning candidates
        //for a party into the winners hashmap.
        List<String> winnerNames = new ArrayList();
        for (int i = 0; i< partySeats; i++ ) { // Goes through and adds however many candidates from the party get seats
            if (partyObject.hasMoreCandidates()) { //will only add more candidates if there's more candidates to add
                winnerNames.add(partyObject.getNextCandidate());
                seatsFilled++;
            }
        }
        winners.put(partyName,winnerNames); // puts an entry with the party name and the winners for that party
    }
    /**
     * Prints the winners of election and other relevant information to the terminal.
     */
    private void printResults() {
        resultsString =  "A total of " + numBallots + " ballots were cast and " + numSeats +" seats were awarded.\n";
        resultsString += "WINNERS\n";
        for (Map.Entry<String,List<String>> entry: winners.entrySet()) {
             resultsString += "The " + entry.getKey() + " party gets " + entry.getValue().size() + " seats. They received overall " +
                    partyVotes.get(entry.getKey()) + " votes.\n";
            if (entry.getValue().size()!= 0) {
                resultsString += "These seats go to:\n";
                for (String winner: entry.getValue()) {
                    resultsString += winner + "\n";
                }
            }
        }
    }
    /**
     *
     * @param party Name of the party we want to get a winner to
     *              Goes through the party remainders and adds the next winner to the winners list
     */
    private void addPartyWinner(String party) {
        if (!winners.containsKey(party)) { // if the party never reached the threshold we need to give it a
            List<String> winnerNames = new ArrayList();
            winners.put(party,winnerNames);
        }
        List<String> winnerNames = winners.get(party);
        PartyOPL partyObject = partyObjects.get(party);
        if (partyObject.hasMoreCandidates()) {
            winnerNames.add(partyObject.getNextCandidate());
            seatsFilled++;
        }
    }
    /**
     *
     * @param remaindersList list of parties and their remainders
     * @param currentIndex current index of party we are looking at
     *                     Goes through the list of parties and gets the number of all parties that have the same number
     *                     of votes as the current party, even if they have no candidates left
     * @return number of parties that are tied
     */
    private int numPartiesTied (List<Map.Entry<String,Double>>  remaindersList,int currentIndex){ // gets number of parties tied
        //counting ones with no candidates
        int counter = 1;
        double currentValue = remaindersList.get(currentIndex).getValue();
        currentIndex--;
        while (currentIndex>=0 && remaindersList.get(currentIndex).getValue()==currentValue) {
            counter++;
            currentIndex--;
        }
        return counter;
    }
    /**
     *
     * @param remaindersList list of parties and their remainders
     * @param currentIndex current index of party we are looking at
     *      *
     * @return list of parties that are tied and have more candidates
     */
    private List<String> tiedParties (List<Map.Entry<String,Double>>  remaindersList,int currentIndex) {
        List<String> tiedParties = new ArrayList();
        double currentValue = remaindersList.get(currentIndex).getValue();
        while (currentIndex>=0 && remaindersList.get(currentIndex).getValue()==currentValue) {
            if (partyObjects.get(remaindersList.get(currentIndex).getKey()).hasMoreCandidates()) {  // makes sure we aren't
                //letting parties win ties if they don't even have any more candidates
                tiedParties.add(remaindersList.get(currentIndex).getKey());
            }
            currentIndex--;
        }
        return tiedParties;
    }
    /**
     *
     * Function goes determines how many seats each party deserves and gets the members from each party for each seat.
     */
    public void calculateResults() {
        double voteThreshold = numBallots/numSeats;
        Map<String,Double> partyVotesRemainder = new HashMap(); // same as party votes but will subtract votes to calculate accurate remainders
        for (Map.Entry<String,Integer> party: partyVotes.entrySet()) {
            int partyVotes = party.getValue();
            int partySeats = (int)Math.floor(partyVotes/voteThreshold); //Determine how many seats the party gets
            partyVotesRemainder.put(party.getKey(),partyVotes - (partySeats * voteThreshold)); // subtracts the votes from the party so the remainder is accurate
            PartyOPL partyObject = partyObjects.get(party.getKey());
            addWinnersForParty(partyObject,partySeats,party.getKey()); //adds the party's winners
        }
        if (seatsFilled!=numSeats) { // seats haven't been filled off threshold so just go through remainders
            List<Map.Entry<String,Double>> remaindersList = new ArrayList(partyVotesRemainder.entrySet());
            Collections.sort(remaindersList, Comparator.comparing(Map.Entry::getValue)); //sorts the remainder from
            //lowest to most amount of votes remaining
            int counter = remaindersList.size()-1;
            while (seatsFilled!=numSeats) { // fills up seats until seats are filled are there no more parties to go through
                List <String> tiedParties = tiedParties(remaindersList,counter);
                int numPartiesTied = numPartiesTied(remaindersList,counter);
                if (numPartiesTied==1) { //current candidate not tied
                    Map.Entry<String,Double> entry = remaindersList.get(counter);
                    addPartyWinner(entry.getKey());
                    counter--;
                }
                else { //there's a tie
                    List<String> tiedWinners = coinFlip(tiedParties,Math.min(numSeats-seatsFilled,numPartiesTied));
                    for (String winner: tiedWinners) {
                        addPartyWinner(winner);
                    }
                    counter-=numPartiesTied;
                }
                if (counter < 0) {
                    counter = remaindersList.size() - 1;
                }
            }
        }
        for(Map.Entry<String,List<String>> entry : winners.entrySet()){
            auditInfo.add(entry.getKey() + " party seat winners: \n" + entry.getValue().toString());
        }
    }

    /**
     *
     * @param candidate Candidate object containing candidates name and party
     * Add vote adds a vote for the party while also adding a vote for the candidate.
     */
    private void addVote(Candidate candidate) { //adds a vote for a candidate
        String party = candidate.getParty();
        partyVotes.put(party,partyVotes.get(party)+1); // updates vote for party
        partyObjects.get(party).addVote(candidate.getName()); //adds a vote for the specific candidate within the party
    }
    /**
     *
     * @param file Name of the file to be read in
     * Runs the election and extracts relevant information such as number of ballots, votes etc. from the file
     */
    public void run(File file) {
        Scanner scanner;
        try {
            scanner = new Scanner(file);
        }
        catch(FileNotFoundException e) {
            System.out.println(e);
            return;
        }
        scanner.nextLine(); //gets past first line
        
        // updates number of seats, ballots, and candidates
        numSeats = scanner.nextInt();
        numBallots = scanner.nextInt();
        numCandidates = scanner.nextInt();
        
        scanner.nextLine(); //clears null character
        for (int i = 0;i<numCandidates;i++) {
            String candidate = scanner.nextLine();
            String name = candidate.split("\\[")[1].split(",")[0];
            String party = candidate.split("\\[")[1].split(",")[1].split(
                    "]")[0];
            if (!partyVotes.containsKey(party)) { // if the party hasn't been added already add it
                partyObjects.put(party,new PartyOPL());
                partyVotes.put(party,0);
            }
            partyObjects.get(party).addCandidate(name); // add the candidate to the party's candidates
            candidates.add(new Candidate(name,party)); // add candidate to the list of candidates to register votes later
        }
        String auditFileName = "Audit.txt";
        auditFile = Paths.get(auditFileName); //create audit file to write to
        while (scanner.hasNextLine()) { // go through the rest of the file and add votes for the candidate
            int candidateIndex = scanner.nextLine().split("1")[0].length();
            Candidate votedCandidate = candidates.get(candidateIndex);
            addVote(votedCandidate);
            auditInfo.add(votedCandidate.getName() + ", " + votedCandidate.getParty()); //format to print later
        }
        calculateResults();
        writeToMedia();
        writeToAudit();
        printResults();
    }
    public void getWriteToMedia(){
        writeToMedia();
    }

    public void getPrintResults(){
        printResults();
    }
	int getNumSeats() {
		return numSeats;
	}

	void setNumSeats(int numSeats) {
		this.numSeats = numSeats;
	}

	void setSeatsFilled(int seatsFilled) {
		this.seatsFilled = seatsFilled;
	}

	int getNumBallots() {
		return numBallots;
	}

	void setNumBallots(int numBallots) {
		this.numBallots = numBallots;
	}

	int getNumCandidates() {
		return numCandidates;
	}

	void setNumCandidates(int numCandidates) {
		this.numCandidates = numCandidates;
	}

	Map<String, Integer> getPartyVotes() {
		return partyVotes;
	}

	void setPartyVotes(Map<String, Integer> partyVotes) {
		this.partyVotes = partyVotes;
	}

	List<Candidate> getCandidates() {
		return candidates;
	}

	void setCandidates(List<Candidate> candidates) {
		this.candidates = candidates;
	}

    //**GETTER FOR TESTING addWinnersForParty(***)**//
    public Map<String,List<String>> getWinners() {
        return winners;
    }

    //**GETTER FOR TESTING addWinnersForParty(***)**//
    public int getSeatsFilled() {
        return seatsFilled;
    }
    //**GETTERS FOR METHOD UNIT TESTS**//
    public List<String> getCoinFlip(List<String> tiedParties, int seatsNeeded){
        return coinFlip(tiedParties,seatsNeeded);
    }

    public void getWriteToAudit(List<String> auditInfo){
        writeToAudit();
    }

	void setPartyObjects(Map<String, PartyOPL> partyObjects2) {
		this.partyObjects = partyObjects2;
	}

}
