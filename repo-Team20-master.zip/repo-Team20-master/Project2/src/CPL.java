import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class CPL {
    private int numSeats = 0;
    private double numBallots = 0;
    private int numParties = 0;
    private int numCandidates = 0;
    private int seatsFilled = 0;
    List <String> auditInfo = new ArrayList();
    private Path auditFile;
    private Map<String,Integer> partyVotes = new HashMap(); // stores the party letter as key and numVotes as value
    private Map<String,PartyCPL> partyObjects = new HashMap(); //stores the party letter as key and party object as value
    private List<String> parties = new ArrayList();
    private Map<String,List<String>> winners = new HashMap();
    private String resultsString = new String();
    private List<String> auditString = new ArrayList();
    
    /**
     * Getter to let the results GUI save the results of the Audit
     * @return Audit file results as a String
     */
    List<String> getAuditFile() { return auditString; }


    //getter for resultsString

    public String getResultsString() {
        return resultsString;
    }

    /**
     *
     * @param tiedParties list of parties that are tied and have candidates left
     * @param seatsNeeded number of seats we have left to fill
     * This method is for deciding tie breakers between parties.
     *      * It will randomly choose a party out of those tied and add to the parties who win the tie. It will then
     *                    remove it from parties under consideration and continue choosing winners until the amount of
     *                    seats needed is fulfilled
     * @return List of parties that won the tie
     */

    private List<String> coinFlip(List<String> tiedParties, int seatsNeeded){
        List<String> chosenParties =new ArrayList();
        int seatsAdded = 0;
        while (seatsNeeded!=seatsAdded) {
            Random rand = new Random();
            int randChoice = rand.nextInt(1000);
            for(int i = 0; i < 100; i++) {//call java's random generator several times to increase randomness
                randChoice = rand.nextInt(1000);
            }
            String addedParty = tiedParties.get(randChoice%tiedParties.size()); // gets random party out of those tied
            chosenParties.add(addedParty);
            tiedParties.remove(addedParty); // removes it so we can't choose it again
            seatsAdded++;
        }
        return chosenParties;
    }

    /**
     *
     * @param party Name of the party we want to get a winner to
     *              Goes through the party remainders and adds the next winner to the winners list
     */
    private void addPartyWinner(String party) {
        if (!winners.containsKey(party)) { // if the party never reached the threshold we need to give it a array
            List<String> winnerNames = new ArrayList();
            winners.put(party,winnerNames);
        }
        List<String> winnerNames = winners.get(party);
        PartyCPL partyObject = partyObjects.get(party);
        if (partyObject.hasMoreCandidates()) {
            winnerNames.add(partyObject.getNextCandidate());
            seatsFilled++;
        }
    }

    /** writeToMedia
     * This method will create a media file for the media to use containing pertinent info
     * that they will want to show. It writes the total ballots cast, the number of seats
     * that were up for election, and the winners - both party and candidate winners with
     * number of votes received for the party.
     */
    private void writeToMedia() {
        try {
            PrintStream console = System.out;
            PrintStream toMediaFile = new PrintStream( new File("Media.txt"));
            System.setOut(toMediaFile);
            System.out.println("A total of " + numBallots + " ballots were cast and " + numSeats +" seats were awarded.");
            System.out.println("WINNERS");
            for (Map.Entry<String,List<String>> entry: winners.entrySet()) { // go through winners and write their name and votes
                System.out.println("The " + entry.getKey() + " party gets " + entry.getValue().size() + " seats. They received overall " +
                        partyVotes.get(entry.getKey()) + " votes.");
                if (entry.getValue().size()!= 0) {
                    System.out.println ("These seats go to:");
                    for (String winner: entry.getValue()) {
                        System.out.println(winner);
                    }
                }
            }
            toMediaFile.close();
            System.setOut(console);
        } catch(IOException e){
            e.printStackTrace();
        }
        
    }

    /**
     *
     * @return void return but this function will end with the Audit.txt file
     * This method creates an audit file with all of the information associated with the election
     * It outputs the type of election, the number of ballots, the number of available seats, the
     * number of candidates running for election, the candidates names listed by party, the number
     * of votes each party got, and then it lists the winners by party.
     * Lastly it will print every single vote cast by candidate name and their party so that everything
     * may be counted and checked manually to assure the system is running fairly.
     */
    private void writeToAudit(){
        List<String> electionInfo = Arrays.asList("CPL Election", "Number of seats up for election: " + numSeats, "Number of ballots submitted: " + (int) numBallots,
                "Number of candidates running: " + numCandidates, "Candidates:\n");
        List<String> partyInfo = new ArrayList<String>();
        for(Map.Entry<String, PartyCPL> entry : partyObjects.entrySet()){
            partyInfo.add("//" + entry.getKey() + " Party received " + partyVotes.get(entry.getKey()) + " votes//\n");
            partyInfo.add(entry.getValue().toString());
        }
        List<String> winningCandidates = new ArrayList<String>();
        winningCandidates.add("***WINNING CANDIDATES***\n");
        for(Map.Entry<String,List<String>> entry : winners.entrySet()){
            winningCandidates.add("From the " + entry.getKey() + " Party:\n");
            winningCandidates.add(entry.getValue().toString() + "\n");
        }
        winningCandidates.add("\n//ELECTION PROGRESSION BY VOTES//\n");
        List<String> output = new ArrayList<String>(electionInfo); //merge all of the different lists into one list for writing to the file
        output.addAll(partyInfo);
        output.addAll(winningCandidates);
        output.addAll(auditInfo);
        auditString = output;
        try {
            Files.write(auditFile, output);
        } catch (IOException e){
            e.printStackTrace();
        }
    }
    /**
    @param partyObject The party object in which we will extract candidates from
    @param partySeats The number of seats that party won
    @param partyName The name of the party
     */
    public void addWinnersForParty(PartyCPL partyObject,int partySeats, String partyName) { // adds party that meet threshold
        List<String> winnerNames = new ArrayList();
        for (int i = 0; i< partySeats; i++ ) {
            if (partyObject.hasMoreCandidates()) {
                winnerNames.add(partyObject.getNextCandidate());
                seatsFilled++;
            }
        }
        winners.put(partyName,winnerNames);
    }

    /**
     * Prints the winners of election and other relevant information to the terminal.
     */
    private void printResults() {
        resultsString = "A total of " + numBallots + " ballots were cast and " + numSeats +" seats were awarded.\n";
        resultsString += "WINNERS\n";
        for (Map.Entry<String,List<String>> entry: winners.entrySet()) {
            resultsString += "The " + entry.getKey() + " party gets " + entry.getValue().size() + " seats. They received overall " +
                    partyVotes.get(entry.getKey()) + " votes.\n";
            if (entry.getValue().size()!= 0) {
                resultsString += "These seats go to:\n";
                for (String winner: entry.getValue()) {
                    resultsString += winner + "\n";
                }
            }
        }
    }

    /**
     *
     * @param remaindersList list of parties and their remainders
     * @param currentIndex current index of party we are looking at
     *                     Goes through the list of parties and gets the number of all parties that have the same number
     *                     of votes as the current party, even if they have no candidates left
     * @return number of parties that are tied
     */
    private int numPartiesTied (List<Map.Entry<String,Double>>  remaindersList,int currentIndex){ // gets number of parties tied
        //counting ones with no candidates
        int counter = 1;
        double currentValue = remaindersList.get(currentIndex).getValue();
        currentIndex--;
        while (currentIndex>=0 && remaindersList.get(currentIndex).getValue()==currentValue) {
            counter++;
            currentIndex--;
        }
        return counter;
    }

    /**
     *
     * @param remaindersList list of parties and their remainders
     * @param currentIndex current index of party we are looking at
     *      *
     * @return list of parties that are tied and have more candidates
     */
    private List<String> tiedParties (List<Map.Entry<String,Double>>  remaindersList,int currentIndex) {
        List<String> tiedParties = new ArrayList();
        double currentValue = remaindersList.get(currentIndex).getValue();
        while (currentIndex>=0 && remaindersList.get(currentIndex).getValue()==currentValue) {
            if (partyObjects.get(remaindersList.get(currentIndex).getKey()).hasMoreCandidates()) {  // makes sure we aren't
                //letting parties win ties if they don't even have any more candidates
                tiedParties.add(remaindersList.get(currentIndex).getKey());
            }
            currentIndex--;
        }
        return tiedParties;
    }
    /**
     *
     * Function goes determines how many seats each party deserves and gets the members from each party for each seat.
     */
    public void calculateResults() { // test divide by zero and whatnot
        double voteThreshold = numBallots/numSeats;
        List<Map.Entry<String,Integer>> entryList = new ArrayList(partyVotes.entrySet());
        Map<String,Double> partyVotesRemainder = new HashMap(); // same as party votes but will subtract votes to calculate accurate remainders
        for (Map.Entry<String,Integer> party: entryList) {
            int partyVotes = party.getValue();
            int partySeats = (int)Math.floor(partyVotes/voteThreshold);
            partyVotesRemainder.put(party.getKey(),partyVotes - (partySeats * voteThreshold)); // subtracts the votes from the party so the remainder is accurate
            PartyCPL partyObject = partyObjects.get(party.getKey());
            addWinnersForParty(partyObject,partySeats,party.getKey());
        }
        if (seatsFilled!=numSeats) { // seats haven't been filled off threshold so just go through remainders
            List<Map.Entry<String,Double>> remaindersList = new ArrayList(partyVotesRemainder.entrySet()); // TODO: Is a new var needed? Are this and partyVotesRemainder the same?
            Collections.sort(remaindersList, Comparator.comparing(Map.Entry::getValue)); //sorts the remainders
            int counter = remaindersList.size()-1;
            while (seatsFilled!=numSeats) { // fills up seats until seats are filled are there no more parties to go through
                List <String> tiedParties = tiedParties(remaindersList,counter);
                int numPartiesTied = numPartiesTied(remaindersList,counter);
                if (numPartiesTied==1) { //current candidate not tied
                    Map.Entry<String,Double> entry = remaindersList.get(counter);
                    addPartyWinner(entry.getKey());
                    counter--;
                }
                else { //there's a tie
                    List<String> tiedWinners = coinFlip(tiedParties,Math.min(numSeats-seatsFilled,numPartiesTied));
                    for (String winner: tiedWinners) {
                        addPartyWinner(winner);
                    }
                    counter-=numPartiesTied;
                }
                if (counter < 0) {
                    counter = remaindersList.size() - 1;
                }
            }
        }

        for(Map.Entry<String,List<String>> entry : winners.entrySet()){
            auditInfo.add(entry.getKey() + " party seat winners:\n" + entry.getValue().toString());
            System.out.println(entry.getKey() + " party seat winners:\n" + entry.getValue().toString());
        }
    }

    /**
     *
     * @param file Name of the file to be read in
     * Runs the election and extracts relevant information such as number of ballots, votes etc. from the file
     */
    public void run(File file) {
        Scanner scanner;
        try {
            scanner = new Scanner(file);
        }
        catch(FileNotFoundException e) {
            System.out.println(e);
            return;
        }
        scanner.nextLine(); //gets past first line
        numParties = scanner.nextInt();
        scanner.nextLine(); // takes off null character
        String[] partyNames = scanner.nextLine().split("\\[")[1].split("]")[0].split(",");
        for (String party: partyNames) {
            partyVotes.put(party,0);
            partyObjects.put(party,new PartyCPL());
            parties.add(party);
        }
        
        numSeats = scanner.nextInt();
        numBallots = scanner.nextInt();
        numCandidates = scanner.nextInt();
        
        scanner.nextLine(); // gets rid of null character
        for (int i = 0;i<numCandidates;i++) {
            String candidate = scanner.nextLine();
            String[] candidateInfo = candidate.split("\\[")[1].split("]")[0].split(",");
            String name = candidateInfo[0];
            String party = candidateInfo[1];
            partyObjects.get(party).addCandidate(name);
        }
        String auditFileName = "Audit.txt";
        auditFile = Paths.get(auditFileName); //create audit file to write to
        while (scanner.hasNextLine()) {
            int partyIndex = scanner.nextLine().split("1")[0].length();
            String votedParty = parties.get(partyIndex);
            partyVotes.put(votedParty,partyVotes.get(votedParty)+1);
            auditInfo.add(votedParty);
        }
        calculateResults();
        writeToMedia();
        writeToAudit();
        printResults();
    }
    public void getWriteToAudit(List<String> auditInfo){
        writeToAudit();
    }
    //**GETTERS FOR METHOD UNIT TESTS**//
    public List<String> getCoinFlip(List<String> tiedParties, int seatsNeeded){
        return coinFlip(tiedParties,seatsNeeded);
    }
    int getNumSeats() {
        return numSeats;
    }

    void setNumSeats(int numSeats) {
        this.numSeats = numSeats;
    }

    double getNumBallots() {
        return numBallots;
    }

    void setNumBallots(double numBallots) {
        this.numBallots = numBallots;
    }

    int getNumParties() {
        return numParties;
    }

    void setNumParties(int numParties) {
        this.numParties = numParties;
    }

    int getNumCandidates() {
        return numCandidates;
    }

    void setNumCandidates(int numCandidates) {
        this.numCandidates = numCandidates;
    }

    Map<String, Integer> getPartyVotes() {
        return partyVotes;
    }

    void setPartyVotes(Map<String, Integer> partyVotes) {
        this.partyVotes = partyVotes;
    }

    Map<String, PartyCPL> getPartyObjects() {
        return partyObjects;
    }

    void setPartyObjects(Map<String, PartyCPL> partyObjects) {
        this.partyObjects = partyObjects;
    }

    List<String> getParties() {
        return parties;
    }

    void setParties(List<String> parties) {
        this.parties = parties;
    }

    void setSeatsFilled(int seatsFilled) {
        this.seatsFilled = seatsFilled;
    }

    int getSeatsFilled() {
        return this.seatsFilled;
    }

    void setWinners(Map<String, List<String>> winners) {
        this.winners = winners;
    }

    Map<String,List<String>> getWinners() {
        return this.winners;
    }
    public void getWriteToMedia(){
        writeToMedia();
    }

    public void getPrintResults(){
        printResults();
    }
}
