import java.util.ArrayList;
import java.util.List;

public class PartyCPL {
    private List<String> candidates = new ArrayList();
    public int candidateIndex = 0;
    public boolean hasMoreCandidates() {
        return candidateIndex < candidates.size();
    }

    /**
     * @return The name of the top voted candiate for the party that has not already been selected
     */
    public String getNextCandidate() { // returns top candidate from the list
        String returnedName =  candidates.get(candidateIndex);
        candidateIndex++;
        return returnedName;
    }

    /**
     *
     * @param name name of the candidate to add
     * Adds the name of teh candidate to the party
     */
    public void addCandidate(String name) {
        candidates.add(name);
    }
    
    // Test getter
    List<String> getCandidates() {
    	return this.candidates;
    }


    public String toString(){
        String allCandidates = new String();
        for(String temp : candidates){
            allCandidates = allCandidates + temp + "\n";
        }
        return allCandidates;
    }
}
