import static org.junit.Assert.*;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

/**
 * @author clayj
 *
 */
public class CPLTest {
	private CPL tester;
	private PartyCPL testParty;
	private PartyCPL testParty2;
	private PartyCPL testParty3;
	private PartyCPL testParty4;
	private Map<String,Integer> partyVotes = new HashMap();
	private Map<String,PartyCPL> partyObjects = new HashMap();

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		System.out.println("setting up...");
		tester = new CPL();
		testParty = new PartyCPL();
		testParty2 = new PartyCPL();
		testParty3 = new PartyCPL();
		testParty4 = new PartyCPL();
		String[] RCandidates= {"Jon Doe", "Jane Doe", "Bob Boberton"};
		for (String temp : RCandidates) {
			testParty.addCandidate(temp);
		}
		String[] DCandidates= {"Bo Bama", "Bo Jiden", "Clint"};
		for (String temp : DCandidates) {
			testParty2.addCandidate(temp);
		}
		String[] ICandidates = {"Green","Bucket"};
		for (String temp : ICandidates) {
			testParty3.addCandidate(temp);
		}
		
		// These will stay the same for all tests, unless otherwise needed
		partyObjects.put("R", testParty);
		partyObjects.put("D", testParty2);
		partyObjects.put("I", testParty3);
		tester.setPartyObjects(partyObjects);
		
		tester.setNumSeats(5);
		tester.setNumCandidates(8);
		tester.setNumBallots(30);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		System.out.println("tearing down...");
	}

	/**
	 * Test method for {@link CPL#addWinnersForParty(PartyCPL, int, java.lang.String)}.
	 */
	@Test
	public void testAddWinnersForParty() {
		tester.addWinnersForParty(testParty, 5, "Republican");
		Map<String,List<String>> winners = tester.getWinners();
		List<String> party = winners.get("Republican");
		assertEquals(party.get(0), "Jon Doe");
		assertEquals(party.get(1), "Jane Doe");
		assertEquals(party.get(2), "Bob Boberton");
		assertEquals(tester.getSeatsFilled(), 3);
		tester.addWinnersForParty(testParty2, 2, "Democrat");
		winners = tester.getWinners();
		party = winners.get("Democrat");
		assertEquals(party.get(0), "Bo Bama");
		assertEquals(party.get(1), "Bo Jiden");
		assertEquals(tester.getSeatsFilled(), 5);
	}

	/**
	 * Test method for {@link CPL#calculateResults(String[])}.
	 * 
	 *
		 * Test 1 conditions:
		 * 	Standard
		 * 	5 seats
		 * 	30 votes
		 * 		D: 12
		 * 		R: 10
		 * 		I: 8
		 * Test 2 conditions:
		 * 	Tie
		 * 	5 seats
		 * 	30 votes
		 * 		D: 12
		 * 		R: 9
		 * 		I: 9
		 * Test 3 conditions:
		 * 	"I" didn't make threshold
		 * 	5 seats
		 * 	30 votes
		 * 		D: 14
		 * 		R: 12
		 * 		I: 4
		 * Test 4 Conditions: 
		 * 	No remainders
		 * 	5 seats
		 * 	30 votes
		 * 		D: 18
		 * 		R: 12
		 * 		I: 0
		 * Test 5 Conditions:
		 * 	3 way tie
		 * 	5 seats
		 * 	30 votes
		 * 		D: 10
		 * 		R: 10
		 * 		I: 10
	*/
	@Test
	public void testCalculateResultsStandard() {
		List<String> auditinfo = new ArrayList<String>();
		tester.setNumSeats(5);
		tester.setNumBallots(30);
		tester.setSeatsFilled(0);
		
		System.out.println("SETUP: Test 1: D-12, R-10, I-8");
		partyVotes.put("D", 12);
		partyVotes.put("R", 10);
		partyVotes.put("I", 8);
		tester.setPartyVotes(partyVotes);
		
		for (int i = 0; i < 12; i++) {
			auditinfo.add("Democrat");
		}
		for (int i = 0; i < 10; i++) {
			auditinfo.add("Republican");
		}
		for (int i = 0; i < 8; i++) {
			auditinfo.add("Idependent");
		}
		
		tester.calculateResults();
		
		Map<String,List<String>> winners = tester.getWinners();
		for (Map.Entry<String,List<String>> entry : winners.entrySet()) {
			if (entry.getKey() == "R") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 2);
			}
			else if (entry.getKey() == "D") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 2);
			}
			else if (entry.getKey() == "I") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 1);
			}
		}
		System.out.println("Test 1 complete!");
	}
	
	/**
	 * Test method for {@link CPL#calculateResults()}.
	 */
	@Test
	public void testCalculateResultsTie() {
		List<String> auditinfo = new ArrayList<String>();
		tester.setNumSeats(5);
		tester.setNumBallots(30);
		tester.setSeatsFilled(0);
		
		System.out.println("SETUP: test 2: D-12, R-9, I-9");
		partyVotes.put("D", 12);
		partyVotes.put("R", 9);
		partyVotes.put("I", 9);
		tester.setPartyVotes(partyVotes);
		for (int i = 0; i < 12; i++) {
			auditinfo.add("Democrat");
		}
		for (int i = 0; i < 9; i++) {
			auditinfo.add("Republican");
		}
		for (int i = 0; i < 9; i++) {
			auditinfo.add("Idependent");
		}
		
		//tester.calculateResults();
		
		Map<String,List<String>> winners = tester.getWinners();
		for (Map.Entry<String,List<String>> entry : winners.entrySet()) {
			if (entry.getKey() == "R") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 1 || partyWinners.size() == 2);
			}
			else if (entry.getKey() == "D") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 2);
			}
			else if (entry.getKey() == "I") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 1 || partyWinners.size() == 2);
			}
		}
		System.out.println("Test 2 complete!");
	}
	
	/**
	 * Test method for {@link CPL#calculateResults()}.
	 */
	@Test
	public void testCalculateResultsThreshold() {
		tester.setNumBallots(30);
		tester.setNumSeats(5);
		tester.setSeatsFilled(0);
		
		System.out.println("SETUP: test 3: D-14, R-12, I-4");
		partyVotes.put("D", 14);
		partyVotes.put("R", 12);
		partyVotes.put("I", 4);
		tester.setPartyVotes(partyVotes);
		
		tester.calculateResults();
		
		Map<String,List<String>> winners = tester.getWinners();
		for (Map.Entry<String,List<String>> entry : winners.entrySet()) {
			if (entry.getKey() == "R") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 2);
			}
			else if (entry.getKey() == "D") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 2);
			}
			if (entry.getKey() == "I") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 1);
			}
		}
		System.out.println("Test 3 complete!");
	}
	
	/**
	 * Test method for {@link CPL#calculateResults()}.
	 */
	@Test
	public void testCalculateResultsNoRemain() {
		List<String> auditinfo = new ArrayList<String>();
		tester.setNumSeats(5);
		tester.setNumBallots(30);
		tester.setSeatsFilled(0);
		
		System.out.println("SETUP: test 4: D-18, R-12");
		partyVotes.put("D", 18);
		partyVotes.put("R", 12);
		partyVotes.put("I", 0);
		tester.setPartyVotes(partyVotes);
		for (int i = 0; i < 18; i++) {
			auditinfo.add("Democrat");
		}
		for (int i = 0; i < 12; i++) {
			auditinfo.add("Republican");
		}
		
		tester.calculateResults();
		
		Map<String,List<String>> winners = tester.getWinners();
		for (Map.Entry<String,List<String>> entry : winners.entrySet()) {
			if (entry.getKey() == "R") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 2);
			}
			else if (entry.getKey() == "D") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 3);
			}
		}
		System.out.println("Test 4 complete!");
	}
	
	/**
	 * Test method for {@link CPL#calculateResults()}.
	 */
	@Test
	public void testCalculateResultsMultiTie() {
		tester.setNumBallots(30);
		tester.setNumSeats(5);
		tester.setSeatsFilled(0);
		
		System.out.println("SETUP: test 5: D-10, R-10, I-10");
		partyVotes.put("D", 10);
		partyVotes.put("R", 10);
		partyVotes.put("I", 10);
		tester.setPartyVotes(partyVotes);
		
		tester.calculateResults();
		Map<String,List<String>> winners = tester.getWinners();
		int totalWinners = 0;
		for (Map.Entry<String,List<String>> entry : winners.entrySet()) {
			if (entry.getKey() == "R") {
				List<String> partyWinners = entry.getValue();
				totalWinners += partyWinners.size();
				assertTrue(partyWinners.size() == 2 || partyWinners.size() == 1);
			}
			else if (entry.getKey() == "D") {
				List<String> partyWinners = entry.getValue();
				totalWinners += partyWinners.size();
				assertTrue(partyWinners.size() == 2 || partyWinners.size() == 1);
			}
			if (entry.getKey() == "I") {
				List<String> partyWinners = entry.getValue();
				totalWinners += partyWinners.size();
				assertTrue(partyWinners.size() == 2 || partyWinners.size() == 1);
			}
		}
		System.out.println(winners.size());
		assertTrue(totalWinners == 5);
		
		System.out.println("Test 5 complete!");
	}
	
	/**
	 * Test method for {@link CPL#run(java.lang.String)}.
	 */
	@Test(expected = Exception.class)
	public void testRunFail() {
		tester.run("testing/test_normal.csv");
	}
	
	/**
	 * Test method for {@link CPL#run(java.lang.String)}.
	 */
	@Test
	public void testRunStress() {
		// Run 100,000 under 5 minutes. When doing other testing comment this out so it goes faster.
		long start = System.currentTimeMillis(); 
		tester.run("testing/test_stress_CPL.csv");
		long end = System.currentTimeMillis(); 
		assertTrue((start - end) <= 300000); // 5 minutes in milliseconds
	}
	
	/**
	 * Test method for {@link CPL#getCoinFlip(String, String)}.
	 */
	@Test
	public void testGetCoinFlip() { // Test coinFlip for 1000 flips to be within 450 and 550. Standard deviation { SQR(1000 * .5 * .5) }
		int min = 450;
		int max = 550;
		int test1Counter1 = 0;
		int test1Counter2 = 0;
		for (int i = 0; i < 1000; i++) {
			List<String> candidates1 = new ArrayList<String>();
			candidates1.add("Joe"); candidates1.add("Bob");
			List<String> results = tester.getCoinFlip(candidates1, 1);
			for (String temp : results) {
				if (temp == "Joe") test1Counter1 += 1;
				else if (temp == "Bob") test1Counter2 += 1;
			}
		}
		assertTrue((test1Counter1 <= max && test1Counter1 >= min) && (test1Counter2 <= max && test1Counter2 >= min));
		
		min = 222;
		max = 444;
		int test2Counter1 = 0;
		int test2Counter2 = 0;
		int test2Counter3 = 0;
		for (int i = 0; i < 1000; i++) {
			List<String> candidates1 = new ArrayList<String>();
			candidates1.add("Joe"); candidates1.add("Bob"); candidates1.add("Jane");
			List<String> results = tester.getCoinFlip(candidates1, 1);
			for (String temp : results) {
				if (temp == "Joe") test2Counter1 += 1;
				else if (temp == "Bob") test2Counter2 += 1;
				else if (temp == "Jane") test2Counter3 += 1;
			}
		}
		assertTrue((test2Counter1 <= max && test2Counter1 >= min) && (test2Counter2 <= max && test2Counter2 >= min) && (test2Counter3 <= max && test2Counter3 >= min));
	}


	/**
	 * Test method for {@link CPL#getWriteToAudit(java.nio.file.Path)}.
	 */
	@Test
	public void testGetWriteToAudit() throws IOException{
		tester.run("testing/test_normal_CPL.csv");
 		Path audit = Paths.get("Audit.txt");
 		Path expect_path = Paths.get("testing/CPL_audit_result_basic");
		List<String> actual = new ArrayList<>();
		List<String> expected = new ArrayList<>();
 		try{
			actual = Files.readAllLines(audit);
		}
		catch(FileNotFoundException e) {
			System.out.println(e);
			fail("io exception");
		}
		try{
            expected = Files.readAllLines(expect_path);
        }
        catch (FileNotFoundException e){
		    System.out.println(e);
		    fail("io exception");
        }
		assertEquals(expected, actual);
	}

	
	/**
	 * Test method for {@link CPL#getWriteToMedia()}.
	 */
	@Test
	public void testGetWriteToMedia() {
		tester.setNumSeats(5);
		tester.setNumBallots(30);
		tester.setSeatsFilled(0);
		
		partyVotes.put("Democrat", 12);
		partyVotes.put("Republican", 10);
		partyVotes.put("Independent", 8);
		tester.setPartyVotes(partyVotes);
		
		tester.addWinnersForParty(testParty, 2, "Republican");
		tester.addWinnersForParty(testParty2, 2, "Democrat");
		tester.addWinnersForParty(testParty3, 1, "Independent");
		
		tester.getWriteToMedia();
	}
	
	/**\
	 * Test method for {@link CPL#getPrintResults()}
	 */
	@Test
	public void testGetPrintResults() {
		tester.setNumSeats(5);
		tester.setNumBallots(30);
		tester.setSeatsFilled(0);
		
		partyVotes.put("Democrat", 12);
		partyVotes.put("Republican", 10);
		partyVotes.put("Independent", 8);
		tester.setPartyVotes(partyVotes);
		
		tester.addWinnersForParty(testParty, 2, "Republican");
		tester.addWinnersForParty(testParty2, 2, "Democrat");
		tester.addWinnersForParty(testParty3, 1, "Independent");
		
		System.out.println("EXPECTED:\nA total of 30.0 ballots were cast and 5 seats were awarded.\r\n" + 
				"WINNERS\r\n" + 
				"The Independent party gets 1 seats. They received overall 8 votes.\r\n" + 
				"These seats go to:\r\n" + 
				"Green\r\n" + 
				"The Democrat party gets 2 seats. They received overall 12 votes.\r\n" + 
				"These seats go to:\r\n" + 
				"Bo Bama\r\n" + 
				"Bo Jiden\r\n" + 
				"The Republican party gets 2 seats. They received overall 10 votes.\r\n" + 
				"These seats go to:\r\n" + 
				"Jon Doe\r\n" + 
				"Jane Doe");
		
		System.out.println("ATCUAL: ");
		tester.getPrintResults();
	}
	
	/**
	 * Test method for {@link PartyCPL#toString()}.
	 */
	@Test
	public void testPartyToString(){
		testParty4.addCandidate("Mayor Pete");
		testParty4.addCandidate("davey");
		testParty4.addCandidate("");
		testParty4.addCandidate("beep boop");
		String actual = testParty4.toString();
		String expected = "Mayor Pete\ndavey\n\nbeep boop\n";
		assertEquals(expected,actual);
	}
	
	/**
	 * Test method for {@link PartyCPL#addCandidate(java.lang.String)}.
	 */
	@Test(expected = IndexOutOfBoundsException.class)
	public void testAddCandidate() {
		// verify setup addCandidate went smoothly
		List<String> candidates = testParty.getCandidates();
		assertEquals(candidates.get(0), "Jon Doe");
		assertEquals(candidates.get(1), "Jane Doe");
		assertEquals(candidates.get(2), "Bob Boberton");
		String exception = candidates.get(3);
	}
	
	/**
	 * Test method for {@link PartyCPL#getNextCandidate()}.
	 */
	@Test(expected = IndexOutOfBoundsException.class)
	public void testGetNextCandidate() {
		assertEquals(testParty.getNextCandidate(), "Jon Doe");
		assertEquals(testParty.getNextCandidate(), "Jane Doe");
		assertEquals(testParty.getNextCandidate(), "Bob Boberton");
		String exception = testParty.getNextCandidate();
	}

	/**
	 * Test method for {@link CPL#run(java.lang.String)}.
	 */
	@Test
    public void testSystemIntegration() {
        tester.run("testing/test_normal_CPL.csv");
    }
}
