import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class OPLTest {
	private OPL tester;
	private PartyOPL testParty;
	private PartyOPL testParty2;
	private PartyOPL testParty3;
	private Map<String,Integer> partyVotes = new HashMap();
	private Map<String,PartyCPL> partyObjects = new HashMap();

	@Before
	public void setUp() throws Exception {
		System.out.println("setting up...");
		tester = new OPL();
		testParty = new PartyOPL();
		testParty2 = new PartyOPL();
		testParty3 = new PartyOPL();
		String[] RCandidates= {"Jon Doe", "Jane Doe", "Bob Boberton"};
		for (String temp : RCandidates) {
			testParty.addCandidate(temp);
		}
		String[] DCandidates= {"Bo Bama", "Bo Jiden", "Clint"};
		for (String temp : DCandidates) {
			testParty2.addCandidate(temp);
		}
		testParty3.addCandidate("Billy");
		testParty3.addCandidate("Bob");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("tearing down...");
	}
	
	/**
	 * Test method for {@link PartyOPL#toString()}.
	 */
	@Test
	public void testPartyToString() {
		String expected = new String();
		testParty3.addVote("Billy");
		testParty3.addVote("Bob");
		testParty3.addVote("Billy");
		String result = testParty3.toString();
		expected = "Billy received 2 vote(s)\nBob received 1 vote(s)\n";
		assertEquals(expected, result);
	}
	
	/**
	 * Test method for {@link OPL#getCoinFlip(String, String)}.
	 */
	@Test
	public void testGetCoinFlip() {
		int min = 450;
		int max = 550;
		int test1Counter1 = 0;
		int test1Counter2 = 0;
		for (int i = 0; i < 1000; i++) {
			List<String> candidates1 = new ArrayList<String>();
			candidates1.add("Joe"); candidates1.add("Bob");
			List<String> results = tester.getCoinFlip(candidates1, 1);
			for (String temp : results) {
				if (temp == "Joe") test1Counter1 += 1;
				else if (temp == "Bob") test1Counter2 += 1;
			}
		}
		assertTrue((test1Counter1 <= max && test1Counter1 >= min) && (test1Counter2 <= max && test1Counter2 >= min));
		
		min = 222;
		max = 444;
		int test2Counter1 = 0;
		int test2Counter2 = 0;
		int test2Counter3 = 0;
		for (int i = 0; i < 1000; i++) {
			List<String> candidates1 = new ArrayList<String>();
			candidates1.add("Joe"); candidates1.add("Bob"); candidates1.add("Jane");
			List<String> results = tester.getCoinFlip(candidates1, 1);
			for (String temp : results) {
				if (temp == "Joe") test2Counter1 += 1;
				else if (temp == "Bob") test2Counter2 += 1;
				else if (temp == "Jane") test2Counter3 += 1;
			}
		}
		System.out.println("" + test2Counter1 + " " + test2Counter2 + " " + test2Counter3);
		assertTrue((test2Counter1 <= max && test2Counter1 >= min) && (test2Counter2 <= max && test2Counter2 >= min) && (test2Counter3 <= max && test2Counter3 >= min));
	}
	
	/**
	 * Test method for {@link PartyOPL#coinFlip(String, String)}.
	 */
	@Test
	public void testCoinFlip() {
		int min = 450;
		int max = 550;
		int test1Counter1 = 0;
		int test1Counter2 = 0;
		for (int i = 0; i < 1000; i++) {
			List<String> candidates1 = new ArrayList<String>();
			candidates1.add("Jon Doe"); candidates1.add("Jane Doe");
			Map<String,Integer> votes = new HashMap();
			votes.put("Jon Doe", 5);
			votes.put("Jane Doe", 5);
			votes.put("Bob Boberton", 4);
			List<Map.Entry<String,Integer>> candidatesList = new ArrayList(votes.entrySet());
			testParty.candidatesList = candidatesList;
			String result = testParty.coinFlip(candidates1);
			if (result == "Jon Doe") test1Counter1 += 1;
			else if (result == "Jane Doe") test1Counter2 += 1;
		}
		assertTrue((test1Counter1 <= max && test1Counter1 >= min) && (test1Counter2 <= max && test1Counter2 >= min));
		
		min = 222;
		max = 444;
		int test2Counter1 = 0;
		int test2Counter2 = 0;
		int test2Counter3 = 0;
		for (int i = 0; i < 1000; i++) {
			List<String> candidates2 = new ArrayList<String>();
			candidates2.add("Jon Doe"); candidates2.add("Jane Doe"); candidates2.add("Bob Boberton");
			Map<String,Integer> votes = new HashMap();
			votes.put("Jon Doe", 5);
			votes.put("Jane Doe", 5);
			votes.put("Bob Boberton", 4);
			List<Map.Entry<String,Integer>> candidatesList = new ArrayList(votes.entrySet());
			testParty.candidatesList = candidatesList;
			String result = testParty.coinFlip(candidates2);
			if (result == "Jon Doe") test2Counter1 += 1;
			else if (result == "Jane Doe") test2Counter2 += 1;
			else if (result == "Bob Boberton") test2Counter3 += 1;
		}
		assertTrue((test2Counter1 <= max && test2Counter1 >= min) && (test2Counter2 <= max && test2Counter2 >= min) && (test2Counter3 <= max && test2Counter3 >= min));
	}

	/**
	 * Test method for {@link OPL#getWriteToMedia()}.
	 */
	@Test
	public void testGetWriteToMedia() {
		tester.setNumBallots(10);
		tester.setNumSeats(5);
		
		testParty.addVote("Jon Doe");
		testParty.addVote("Jon Doe");
		testParty.addVote("Jon Doe");
		testParty.addVote("Jane Doe");
		testParty.addVote("Jane Doe");
		testParty.addVote("Bob Boberton");
		partyVotes.put("Republican", 6);
		// Should add John, then Jane, then Bob
		tester.addWinnersForParty(testParty, 3, "Republican");
		
		testParty2.addVote("Bo Bama");
		testParty2.addVote("Bo Bama");
		testParty2.addVote("Bo Bama");
		testParty2.addVote("Bo Jiden");
		testParty2.addVote("Bo Jiden");
		testParty2.addVote("Clint");
		partyVotes.put("Democrat",6);
		// Should add Bo Bama, then Jiden
		tester.addWinnersForParty(testParty2, 2, "Democrat");
		
		tester.setPartyVotes(partyVotes);
		
		tester.getWriteToMedia();
	}
	
	/**
	 * Test method for {@link OPL#getWriteToAudit(java.nio.file.Path)}.
	 * @throws IOException 
	 */
	@Test
	public void testGetWriteToAudit() throws IOException {
		tester.run("testing/test_normal.csv");
 		Path audit = Paths.get("Audit.txt");
 		Path expect_path = Paths.get("testing/OPL_audit_result_basic");
		List<String> actual = new ArrayList<>();
		List<String> expected = new ArrayList<>();
 		try{
			actual = Files.readAllLines(audit);
		}
		catch(FileNotFoundException e) {
			System.out.println(e);
			fail("io exception");
		}
		try{
            expected = Files.readAllLines(expect_path);
        }
        catch (FileNotFoundException e){
		    System.out.println(e);
		    fail("io exception");
        }
		assertEquals(expected, actual);
	}
	
	/**
	 * Test method for {@link OPL#getPrintResults()}.
	 */
	@Test
	public void testGetPrintResults() {
		tester.setNumBallots(10);
		tester.setNumSeats(5);
		
		testParty.addVote("Jon Doe");
		testParty.addVote("Jon Doe");
		testParty.addVote("Jon Doe");
		testParty.addVote("Jane Doe");
		testParty.addVote("Jane Doe");
		testParty.addVote("Bob Boberton");
		partyVotes.put("Republican", 6);
		// Should add John, then Jane, then Bob
		tester.addWinnersForParty(testParty, 3, "Republican");
		
		testParty2.addVote("Bo Bama");
		testParty2.addVote("Bo Bama");
		testParty2.addVote("Bo Bama");
		testParty2.addVote("Bo Jiden");
		testParty2.addVote("Bo Jiden");
		testParty2.addVote("Clint");
		partyVotes.put("Democrat",6);
		// Should add Bo Bama, then Jiden
		tester.addWinnersForParty(testParty2, 2, "Democrat");
		
		tester.setPartyVotes(partyVotes);
		
		System.out.println("EXPECTED: \nA total of 10 ballots were cast and 5 seats were awarded.\r\n" + 
				"WINNERS\r\n" + 
				"The Democrat party gets 2 seats. They received overall 6 votes.\r\n" + 
				"These seats go to:\r\n" + 
				"Bo Bama\r\n" + 
				"Bo Jiden\r\n" + 
				"The Republican party gets 3 seats. They received overall 6 votes.\r\n" + 
				"These seats go to:\r\n" + 
				"John Doe\r\n" + 
				"Jane Doe\r\n" + 
				"Bob Boberton\nACTUAL:");
		tester.getPrintResults();
	}

	/**
	 * Test method for {@link OPL#addWinnderForParty(PartyOPL, int, java.lang.String)}.
	 */
	@Test
	public void testAddWinnersForParty() {
		testParty.addVote("Jon Doe");
		testParty.addVote("Jon Doe");
		testParty.addVote("Jon Doe");
		testParty.addVote("Jane Doe");
		testParty.addVote("Jane Doe");
		testParty.addVote("Bob Boberton");
		// Should add John, then Jane, then Bob
		tester.addWinnersForParty(testParty, 3, "Republican");
		Map<String,List<String>> winners = tester.getWinners();
		List<String> party = winners.get("Republican");
		assertEquals(party.get(0), "Jon Doe");
		assertEquals(party.get(1), "Jane Doe");
		assertEquals(party.get(2), "Bob Boberton");
		assertEquals(tester.getSeatsFilled(), 3);
		
		testParty2.addVote("Bo Bama");
		testParty2.addVote("Bo Bama");
		testParty2.addVote("Bo Bama");
		testParty2.addVote("Bo Jiden");
		testParty2.addVote("Bo Jiden");
		testParty2.addVote("Clint");
		// Should add Bo Bama, then Jiden
		tester.addWinnersForParty(testParty2, 2, "Democrat");
		party = winners.get("Democrat");
		assertEquals(party.get(0), "Bo Bama");
		assertTrue(party.get(1).equals("Bo Jiden"));
		assertEquals(tester.getSeatsFilled(), 5);
		
		testParty3.addCandidate("Billy");
		tester.addWinnersForParty(testParty3, 0, "Independent");
		assertEquals(tester.getSeatsFilled(), 5);
	}

	/**
	 * Test method for {@link CPL#calculateResults()}.
	 */
	@Test
	public void testCalculateResults() {
		// Test from test.csv (From first part PDF)
		
		// Set up variables
		tester.setNumSeats(3);
		tester.setNumBallots(9);
		tester.setNumCandidates(6);
		tester.setSeatsFilled(0);
		List<String> auditinfo = new ArrayList<String>();
		
		// Set partyVotes
		partyVotes.put("R", 3);
		partyVotes.put("D", 5);
		partyVotes.put("I", 1);
		tester.setPartyVotes(partyVotes);
		
		// Make PartyOPL objects
		PartyOPL RTest = new PartyOPL();
		PartyOPL DTest = new PartyOPL();
		PartyOPL ITest = new PartyOPL();
		
		// Candidates names
		String[] RCandidates = {"Deutsch", "Borg", "Jones"};
		String[] DCandidates = {"Pike", "Foster"};
		String   ICandidates = "Smith";
		
		// Set candidates and add to partyOPL objects
		List<Candidate> candidates = new ArrayList<Candidate>();
		for (String temp : RCandidates) {
			candidates.add(new Candidate(temp,"Republican"));
			RTest.addCandidate(temp);
		}
		for (String temp : DCandidates) {
			candidates.add(new Candidate(temp, "Democrat"));
			DTest.addCandidate(temp);
		}
		candidates.add(new Candidate(ICandidates, "Independent"));
		ITest.addCandidate(ICandidates);
		
		Map<String, PartyOPL> partyObjects = new HashMap();
		partyObjects.put("D", DTest);
		partyObjects.put("R", RTest);
		partyObjects.put("I", ITest);
		tester.setCandidates(candidates);
		tester.setPartyObjects(partyObjects);
		
		// set auditinfo
		for (int i = 0; i < 3; i++) {
			auditinfo.add("Republican");
		}
		for (int i = 0; i < 5; i++) {
			auditinfo.add("Democrat");
		}
		auditinfo.add("Independent");
		
		// add votes to partyOPL objects
		DTest.addVote("Pike");
		DTest.addVote("Pike");
		DTest.addVote("Foster");
		RTest.addVote("Jones");
		ITest.addVote("Smith");
		RTest.addVote("Borg");
		RTest.addVote("Borg");
		DTest.addVote("Pike");
		DTest.addVote("Foster");
		
		tester.calculateResults();
		
		// Should be 2 dems and 1 Repub
		Map<String,List<String>> winners = tester.getWinners();
		for (Map.Entry<String,List<String>> entry : winners.entrySet()) {
			if (entry.getKey() == "Republican") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 1);
			}
			else if (entry.getKey() == "Democrat") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 2);
			}
		}
		System.out.println("Test Calc Results Normal Complete!");
	}
	
	/**
	 * Test method for {@link CPL#calculateResults()}.
	 */
	@Test
	public void testCalculateResultsNoCandidate() {
		// Set up variables
		tester.setNumSeats(3);
		tester.setNumBallots(12);
		tester.setNumCandidates(6);
		tester.setSeatsFilled(0);
		List<String> auditinfo = new ArrayList<String>();
		
		// Set partyVotes
		partyVotes.put("R", 0);
		partyVotes.put("D", 5);
		partyVotes.put("I", 7);
		tester.setPartyVotes(partyVotes);
		
		// Make PartyOPL objects
		PartyOPL RTest = new PartyOPL();
		PartyOPL DTest = new PartyOPL();
		PartyOPL ITest = new PartyOPL();
		
		// Candidates names
		String[] RCandidates = {"Deutsch", "Borg", "Jones"};
		String[] DCandidates = {"Pike", "Foster"};
		String   ICandidates = "Smith";
		
		// Set candidates and add to partyOPL objects
		List<Candidate> candidates = new ArrayList<Candidate>();
		for (String temp : RCandidates) {
			candidates.add(new Candidate(temp,"Republican"));
			RTest.addCandidate(temp);
		}
		for (String temp : DCandidates) {
			candidates.add(new Candidate(temp, "Democrat"));
			DTest.addCandidate(temp);
		}
		candidates.add(new Candidate(ICandidates, "Independent"));
		ITest.addCandidate(ICandidates);
		
		Map<String, PartyOPL> partyObjects = new HashMap();
		partyObjects.put("D", DTest);
		partyObjects.put("R", RTest);
		partyObjects.put("I", ITest);
		tester.setCandidates(candidates);
		tester.setPartyObjects(partyObjects);
		
		// set auditinfo
		for (int i = 0; i < 0; i++) {
			auditinfo.add("Republican");
		}
		for (int i = 0; i < 5; i++) {
			auditinfo.add("Democrat");
		}
		auditinfo.add("Independent");
		
		// add votes to partyOPL objects
		DTest.addVote("Pike");
		DTest.addVote("Pike");
		DTest.addVote("Foster");
		ITest.addVote("Smith");
		ITest.addVote("Smith");
		ITest.addVote("Smith");
		ITest.addVote("Smith");
		ITest.addVote("Smith");
		ITest.addVote("Smith");
		ITest.addVote("Smith");
		DTest.addVote("Pike");
		DTest.addVote("Foster");
		
		tester.calculateResults();
		
		// Should be 2 dems and 1 Repub
		Map<String,List<String>> winners = tester.getWinners();
		for (Map.Entry<String,List<String>> entry : winners.entrySet()) {
			if (entry.getKey() == "Independent") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 1);
			}
			else if (entry.getKey() == "Democrat") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 2);
			}
		}
		System.out.println("Test Calc Results No Candidate Complete!");
	}
	
	/**
	 * Test method for {@link CPL#calculateResults()}.
	 */
	@Test
	public void testCalculateResultsCandidateTie() {
		// Set up variables
		tester.setNumSeats(3);
		tester.setNumBallots(11);
		tester.setNumCandidates(6);
		tester.setSeatsFilled(0);
		List<String> auditinfo = new ArrayList<String>();
		
		// Set partyVotes
		partyVotes.put("R", 5);
		partyVotes.put("D", 5);
		partyVotes.put("I", 1);
		tester.setPartyVotes(partyVotes);
		
		// Make PartyOPL objects
		PartyOPL RTest = new PartyOPL();
		PartyOPL DTest = new PartyOPL();
		PartyOPL ITest = new PartyOPL();
		
		// Candidates names
		String[] RCandidates = {"Deutsch", "Borg", "Jones"};
		String[] DCandidates = {"Pike", "Foster"};
		String   ICandidates = "Smith";
		
		// Set candidates and add to partyOPL objects
		List<Candidate> candidates = new ArrayList<Candidate>();
		for (String temp : RCandidates) {
			candidates.add(new Candidate(temp,"Republican"));
			RTest.addCandidate(temp);
		}
		for (String temp : DCandidates) {
			candidates.add(new Candidate(temp, "Democrat"));
			DTest.addCandidate(temp);
		}
		candidates.add(new Candidate(ICandidates, "Independent"));
		ITest.addCandidate(ICandidates);
		
		Map<String, PartyOPL> partyObjects = new HashMap();
		partyObjects.put("D", DTest);
		partyObjects.put("R", RTest);
		partyObjects.put("I", ITest);
		tester.setCandidates(candidates);
		tester.setPartyObjects(partyObjects);
		
		// set auditinfo
		for (int i = 0; i < 5; i++) {
			auditinfo.add("Republican");
		}
		for (int i = 0; i < 5; i++) {
			auditinfo.add("Democrat");
		}
		auditinfo.add("Independent");
		
		// add votes to partyOPL objects
		DTest.addVote("Pike");
		DTest.addVote("Pike");
		DTest.addVote("Foster");
		RTest.addVote("Jones");
		RTest.addVote("Jones");
		ITest.addVote("Smith");
		RTest.addVote("Borg");
		RTest.addVote("Borg");
		DTest.addVote("Pike");
		DTest.addVote("Foster");
		RTest.addVote("Deutsch");
		
		tester.calculateResults();
		
		// Should be 2 dems and 1 Repub
		Map<String,List<String>> winners = tester.getWinners();
		for (Map.Entry<String,List<String>> entry : winners.entrySet()) {
			if (entry.getKey() == "Republican") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.get(0) == "Jones" || partyWinners.get(0) == "Borg");
			}
			else if (entry.getKey() == "Democrat") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 2);
			}
		}
		System.out.println("Test Calc Results Candidate Tie Complete!");
	}
	
	/**
	 * Test method for {@link CPL#calculateResults()}.
	 */
	@Test
	public void testCalculateResultsPartyTie() {
		// Set up variables
		tester.setNumSeats(3);
		tester.setNumBallots(11);
		tester.setNumCandidates(6);
		tester.setSeatsFilled(0);
		List<String> auditinfo = new ArrayList<String>();
		
		// Set partyVotes
		partyVotes.put("R", 5);
		partyVotes.put("D", 5);
		partyVotes.put("I", 1);
		tester.setPartyVotes(partyVotes);
		
		// Make PartyOPL objects
		PartyOPL RTest = new PartyOPL();
		PartyOPL DTest = new PartyOPL();
		PartyOPL ITest = new PartyOPL();
		
		// Candidates names
		String[] RCandidates = {"Deutsch", "Borg", "Jones"};
		String[] DCandidates = {"Pike", "Foster"};
		String   ICandidates = "Smith";
		
		// Set candidates and add to partyOPL objects
		List<Candidate> candidates = new ArrayList<Candidate>();
		for (String temp : RCandidates) {
			candidates.add(new Candidate(temp,"Republican"));
			RTest.addCandidate(temp);
		}
		for (String temp : DCandidates) {
			candidates.add(new Candidate(temp, "Democrat"));
			DTest.addCandidate(temp);
		}
		candidates.add(new Candidate(ICandidates, "Independent"));
		ITest.addCandidate(ICandidates);
		
		Map<String, PartyOPL> partyObjects = new HashMap();
		partyObjects.put("D", DTest);
		partyObjects.put("R", RTest);
		partyObjects.put("I", ITest);
		tester.setCandidates(candidates);
		tester.setPartyObjects(partyObjects);
		
		// set auditinfo
		for (int i = 0; i < 5; i++) {
			auditinfo.add("Republican");
		}
		for (int i = 0; i < 5; i++) {
			auditinfo.add("Democrat");
		}
		auditinfo.add("Independent");
		
		// add votes to partyOPL objects
		DTest.addVote("Pike");
		DTest.addVote("Pike");
		DTest.addVote("Foster");
		RTest.addVote("Jones");
		RTest.addVote("Jones");
		ITest.addVote("Smith");
		RTest.addVote("Borg");
		RTest.addVote("Borg");
		RTest.addVote("Borg");
		DTest.addVote("Pike");
		DTest.addVote("Foster");
		
		tester.calculateResults();
		
		// Should be 2 dems and 1 Repub
		Map<String,List<String>> winners = tester.getWinners();
		for (Map.Entry<String,List<String>> entry : winners.entrySet()) {
			if (entry.getKey() == "Republican") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 1 || partyWinners.size() == 2);
			}
			else if (entry.getKey() == "Democrat") {
				List<String> partyWinners = entry.getValue();
				assertTrue(partyWinners.size() == 1 || partyWinners.size() == 2);
			}
		}
		assertTrue(winners.size() == 3);
		System.out.println("Test Calc Results Party Tie Complete!");
	}

	/**
	 * Test method for {@link CPL#run(String)}.
	 */
	@Test
	public void testSystemIntegration() {
		tester.run("testing/test_normal.csv");
	}
	
	/**
	 * Test method for {@link CPL#run(String)}.
	 */
	@Test(expected = InputMismatchException.class)
	public void testRunFail() {
		tester.run("testing/test_normal_CPL.csv");;
	}
	
	/**
	 * Test method for {@link PartyCPL#getNextCandidate()}.
	 */
	@Test
	public void testGetNextCandidate() {
		testParty.addVote("Jon Doe");		// 1
		testParty.addVote("Jane Doe");		// 1
		testParty.addVote("Bob Boberton");	// 1
		testParty.addVote("Jane Doe");		// 2
		testParty.addVote("Jon Doe");		// 2
		testParty.addVote("Jane Doe");		// 3
		testParty.addVote("Jane Doe");		// 4
		testParty.addVote("Bob Boberton");	// 2
		testParty.addVote("Jon Doe");		// 3
		
		Map<String,Integer> votes = new HashMap();
		votes.put("Jon Doe", 5);
		votes.put("Jane Doe", 5);
		votes.put("Bob Boberton", 4);
		List<Map.Entry<String,Integer>> candidatesList = new ArrayList(votes.entrySet());
		Collections.sort(candidatesList, Comparator.comparing(Map.Entry::getValue));
		testParty.candidatesList = candidatesList;
		
		// Should grab Jane, Jon, Bob, Joe
		assertEquals(testParty.getNextCandidate(), "Jane Doe");
		assertEquals(testParty.getNextCandidate(), "Jon Doe");
		assertEquals(testParty.getNextCandidate(), "Bob Boberton");
		System.out.println(testParty.getCandidates().size());
	}

	/**
	 * Test method for {@link PartyCPL#hasMoreCandidates()}.
	 */
	@Test
	public void testHasMoreCandidates() {
		testParty.addVote("Jon Doe");		// 1
		testParty.addVote("Jane Doe");		// 1
		testParty.addVote("Bob Boberton");	// 1
		testParty.addVote("Jane Doe");		// 2
		testParty.addVote("Jon Doe");		// 2
		testParty.addVote("Jane Doe");		// 3
		testParty.addVote("Jane Doe");		// 4
		testParty.addVote("Bob Boberton");	// 2
		testParty.addVote("Jon Doe");		// 3
		
		Map<String,Integer> votes = new HashMap();
		votes.put("Jon Doe", 5);
		votes.put("Jane Doe", 5);
		votes.put("Bob Boberton", 4);
		List<Map.Entry<String,Integer>> candidatesList = new ArrayList(votes.entrySet());
		Collections.sort(candidatesList, Comparator.comparing(Map.Entry::getValue));
		testParty.candidatesList = candidatesList;
		
		String candidate = testParty.getNextCandidate();
		System.out.println(candidate);
		candidate = testParty.getNextCandidate();
		System.out.println(candidate);
		candidate = testParty.getNextCandidate();
		System.out.println(candidate);
		System.out.println(testParty.candidatesList.size());
		
		if (testParty.hasMoreCandidates()) {
			fail("No more candidates");
		}
		
	}
	
	/**
	 * Test method for {@link PartyCPL#addVote()}.
	 */
	@Test
	public void testAddVote() {
		testParty3.addVote("Billy");	// Test adding to something not in map
		testParty3.addCandidate("Bob");
		testParty3.addVote("Billy");	// Test adding to something in map
		testParty3.addVote("Bob");
		
		Map<String,Integer> candidates = testParty3.getCandidates();
		assertTrue(candidates.get("Billy").equals(2));
		assertTrue(candidates.get("Bob").equals(1));
	}
	
	/**
	 * Test method for {@link PartyCPL#addCandidate()}.
	 */
	@Test(expected = IndexOutOfBoundsException.class)
	public void testAddCandidate() {
		// verify adding candidates in setup was done properly
		List<String> candidates = new ArrayList<String>(testParty.getCandidates().keySet());
		assertEquals(candidates.get(0), "Jon Doe");
		assertEquals(candidates.get(1), "Bob Boberton");	// when transferring from keyset to list order gets messed up
		assertEquals(candidates.get(2), "Jane Doe");
		String exception = candidates.get(3);
	}
}
