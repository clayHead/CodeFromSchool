# 4061-proj4
A server program and two client programs to communicate.

## Members

| Member Name | x500   |
|-------------|--------|
| Chase       |joh13266|
| Clayton     |joh13124|
| Modou       |jawxx001|

## Contributions

| Member Name | Contributions |
|-------------|--------------|
| Modou       | Tested for bugs |
| Chase       | Implemented shared memory, communication system |
| Clayton     | Tested for bugs |

## Known Bugs

No known bugs

## Test Cases Used

## Extra Credit
